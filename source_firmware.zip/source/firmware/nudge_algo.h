/*
 * LWCloneU2 Resurrected - nudge processing for the ADXL335 (VPINBALL)
 * Copyright (C) 2026 Frischbrot
 *
 * This program is free software; you can redistribute it and/or modify it under the terms of the
 * GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * Pure integer code without AVR dependencies (also compiled by the PC test harness).
 * Called every NUDGE_TICK_MS with the averaged ADC values of X and Y.
 *
 * Processing per tick:
 *   1. slow tracker of the raw values (~16 ms)
 *   2. baseline: set at startup (or from EEPROM), then automatic re-centering while the
 *      sensor is steady (no nudge, no vibration) -> no drift, board need not be level
 *   3. mounting orientation (rotation 0/90/180/270, mirror X/Y)
 *   4. low-pass filter (adjustable)
 *   5. tilt detection -> key T
 *   6. dead zone (soft, no jump at the edge)
 *   7. rebound damping (counter-swing after a strong nudge)
 *   8. gating: zero while a selected output (shaker, coils) is on and shortly after
 *   9. scaling to 16 bit, +/-32767 = +/-1 g
 */

#ifndef NUDGE_ALGO_H__INCLUDED
#define NUDGE_ALGO_H__INCLUDED

#include <stdint.h>

#define NUDGE_TICK_MS        2
#define NUDGE_C_PER_G        1877   /* ADC counts x16 per g: ADXL335 at 3.3 V (330 mV/g), AREF ~2.88 V (3.3 V via 4.7k) */
#define NUDGE_RAW_MAX        16368  /* 1023 x 16 */

#define NUDGE_STARTUP_TICKS  50     /* 100 ms: baseline follows directly */
#define NUDGE_QUIET_LIMIT    38     /* 0.02 g: steadier than this counts as "at rest" */
#define NUDGE_QUIET_TICKS    125    /* 250 ms at rest before re-centering starts */
#define NUDGE_CENTER_SHIFT   9      /* re-centering time constant 512 ticks ~ 1 s */
#define NUDGE_REBOUND_TRIG   282    /* 0.15 g */
#define NUDGE_REBOUND_TICKS  75     /* 150 ms */
#define NUDGE_TILT_TICKS     75     /* key T held 150 ms */
#define NUDGE_TILT_LOCK      500    /* then 1 s pause */

/* orientation bits */
#define NUDGE_OR_ROT_MASK    0x03   /* 0 = 0, 1 = 90, 2 = 180, 3 = 270 degrees */
#define NUDGE_OR_MIRROR_X    0x04
#define NUDGE_OR_MIRROR_Y    0x08
#define NUDGE_OR_NO_CENTER   0x10   /* automatic re-centering off */

/* status bits (reported as gamepad buttons 1-8, read by the tool) */
#define NUDGE_ST_GATED       0x01
#define NUDGE_ST_TILT        0x02
#define NUDGE_ST_CENTERING   0x04
#define NUDGE_ST_STORED_ZERO 0x08

typedef struct {
	uint8_t deadzone_mg;     /* 0..255 mg */
	uint8_t filter;          /* 0 (off) .. 4 (strong) */
	uint8_t tilt_10mg;       /* tilt threshold in 10 mg, 0 = off */
	uint8_t orient;          /* NUDGE_OR_... */
	uint8_t rebound_pct;     /* 0..100 % damping of the counter-swing */
	uint8_t gate_hold_10ms;  /* hold time after the gated outputs are off */
	uint32_t gate_mask;      /* bit 0 = output 1 ... bit 31 = output 32 */
} nudge_cfg_t;

typedef struct {
	int32_t base[2];         /* baseline in counts16 << 8 */
	int32_t slow[2];         /* slow tracker, counts16 << 4 */
	int32_t filt[2];         /* filtered value, counts16 << 4 */
	uint16_t ticks;          /* ticks since start (saturating) */
	uint16_t quiet;          /* ticks at rest */
	uint16_t gate;           /* gating ticks left */
	uint8_t reb_t[2];
	int8_t reb_s[2];
	uint16_t tilt_t;
	uint16_t tilt_lock;
	uint8_t stored_zero;     /* baseline came from EEPROM / "set zero" */
	int16_t out[2];          /* report X/Y, +/-32767 = +/-1 g */
	int8_t raw8[2];          /* centered, before filter/dead zone/gating, +/-127 = +/-1 g */
	uint8_t status;
} nudge_state_t;


static inline int16_t nudge_abs16(int16_t v) { return v < 0 ? (int16_t)-v : v; }

static inline int16_t nudge_clamp16(int32_t v, int16_t lim)
{
	if (v > lim) return lim;
	if (v < -lim) return (int16_t)-lim;
	return (int16_t)v;
}

static inline void nudge_cfg_defaults(nudge_cfg_t *c)
{
	c->deadzone_mg = 15;
	c->filter = 2;
	c->tilt_10mg = 70;       /* 0.70 g */
	c->orient = 0;
	c->rebound_pct = 50;
	c->gate_hold_10ms = 10;  /* 100 ms */
	c->gate_mask = 0;
}

static inline void nudge_cfg_sanitize(nudge_cfg_t *c)
{
	if (c->filter > 4) c->filter = 4;
	if (c->rebound_pct > 100) c->rebound_pct = 100;
	c->orient &= (NUDGE_OR_ROT_MASK | NUDGE_OR_MIRROR_X | NUDGE_OR_MIRROR_Y | NUDGE_OR_NO_CENTER);
}

/* zero_valid: zx/zy (raw counts16) from EEPROM are used as start baseline */
static inline void nudge_init(nudge_state_t *s, uint8_t zero_valid, int16_t zx, int16_t zy)
{
	uint8_t *p = (uint8_t *)s;
	for (uint16_t i = 0; i < sizeof(*s); i++) p[i] = 0;

	if (zero_valid)
	{
		s->base[0] = (int32_t)zx << 8;
		s->base[1] = (int32_t)zy << 8;
		s->stored_zero = 1;
	}
}

/* "set zero now": current rest position becomes the baseline */
static inline void nudge_set_zero(nudge_state_t *s, int16_t *zx, int16_t *zy)
{
	s->base[0] = s->slow[0] << 4;
	s->base[1] = s->slow[1] << 4;
	s->filt[0] = 0;
	s->filt[1] = 0;
	s->quiet = 0;
	s->stored_zero = 1;
	*zx = (int16_t)(s->slow[0] >> 4);
	*zy = (int16_t)(s->slow[1] >> 4);
}

static inline void nudge_orient(uint8_t o, int16_t *x, int16_t *y)
{
	int16_t a = *x, b = *y;

	switch (o & NUDGE_OR_ROT_MASK)
	{
	case 1: *x = (int16_t)-b; *y = a; break;
	case 2: *x = (int16_t)-a; *y = (int16_t)-b; break;
	case 3: *x = b; *y = (int16_t)-a; break;
	default: break;
	}

	if (o & NUDGE_OR_MIRROR_X) *x = (int16_t)-*x;
	if (o & NUDGE_OR_MIRROR_Y) *y = (int16_t)-*y;
}

/* returns 1 if the state of the tilt key changed */
static inline uint8_t nudge_tick(nudge_state_t *s, const nudge_cfg_t *c, const int16_t raw[2], uint8_t gate_now)
{
	uint8_t const was_tilt = (s->tilt_t > 0);
	uint8_t at_rest = 1;
	int16_t v[2];

	/* 1. slow tracker, 2. baseline */
	for (uint8_t i = 0; i < 2; i++)
	{
		if (s->ticks == 0)
			s->slow[i] = (int32_t)raw[i] << 4;
		else
			s->slow[i] += (((int32_t)raw[i] << 4) - s->slow[i]) >> 3;

		if (nudge_abs16((int16_t)(raw[i] - (int16_t)(s->slow[i] >> 4))) >= NUDGE_QUIET_LIMIT)
			at_rest = 0;

		if (!s->stored_zero && s->ticks < NUDGE_STARTUP_TICKS)
			s->base[i] = s->slow[i] << 4;
	}

	if (s->ticks < 0xFFFF) s->ticks++;

	/* 8a. gating timer */
	if (gate_now)
		s->gate = (uint16_t)c->gate_hold_10ms * (10 / NUDGE_TICK_MS) + 1;
	else if (s->gate > 0)
		s->gate--;

	uint8_t const gated = (s->gate > 0);

	if (at_rest && !gated) {
		if (s->quiet < 0xFFFF) s->quiet++;
	} else {
		s->quiet = 0;
	}

	uint8_t const centering = (s->quiet >= NUDGE_QUIET_TICKS) && !(c->orient & NUDGE_OR_NO_CENTER);

	if (centering)
	{
		for (uint8_t i = 0; i < 2; i++)
			s->base[i] += ((s->slow[i] << 4) - s->base[i]) >> NUDGE_CENTER_SHIFT;
	}

	/* centered values, 3. orientation */
	v[0] = (int16_t)(raw[0] - (int16_t)(s->base[0] >> 8));
	v[1] = (int16_t)(raw[1] - (int16_t)(s->base[1] >> 8));
	nudge_orient(c->orient, &v[0], &v[1]);

	s->raw8[0] = (int8_t)nudge_clamp16(((int32_t)v[0] * 69) >> 10, 127);
	s->raw8[1] = (int8_t)nudge_clamp16(((int32_t)v[1] * 69) >> 10, 127);

	/* 4. low-pass */
	for (uint8_t i = 0; i < 2; i++)
	{
		int32_t const x16 = (int32_t)v[i] << 4;
		if (c->filter == 0)
			s->filt[i] = x16;
		else
			s->filt[i] += (x16 - s->filt[i]) >> c->filter;
		v[i] = (int16_t)(s->filt[i] >> 4);
	}

	/* 5. tilt -> key T */
	if (s->tilt_t > 0) s->tilt_t--;
	if (s->tilt_lock > 0) s->tilt_lock--;

	if (c->tilt_10mg != 0 && !gated && s->tilt_lock == 0)
	{
		int16_t const thr = (int16_t)(((int32_t)c->tilt_10mg * NUDGE_C_PER_G) / 100);
		int16_t const m = nudge_abs16(v[0]) > nudge_abs16(v[1]) ? nudge_abs16(v[0]) : nudge_abs16(v[1]);
		if (m > thr)
		{
			s->tilt_t = NUDGE_TILT_TICKS;
			s->tilt_lock = NUDGE_TILT_LOCK;
		}
	}

	/* 6. dead zone, 7. rebound damping, 8b. gating, 9. scaling */
	int16_t const dz = (int16_t)(((int32_t)c->deadzone_mg * NUDGE_C_PER_G) / 1000);

	for (uint8_t i = 0; i < 2; i++)
	{
		int16_t x = v[i];

		if (nudge_abs16(x) <= dz) x = 0;
		else x = (x > 0) ? (int16_t)(x - dz) : (int16_t)(x + dz);

		if (s->reb_t[i] > 0) s->reb_t[i]--;

		int8_t const sg = (x > 0) ? 1 : ((x < 0) ? -1 : 0);

		if (s->reb_t[i] > 0 && sg != 0 && sg == -s->reb_s[i])
		{
			x = (int16_t)(((int32_t)x * (100 - c->rebound_pct)) / 100);
		}
		else if (nudge_abs16(x) > NUDGE_REBOUND_TRIG)
		{
			s->reb_s[i] = sg;
			s->reb_t[i] = NUDGE_REBOUND_TICKS;
		}

		if (gated) x = 0;

		s->out[i] = nudge_clamp16(((int32_t)x * 1117) >> 6, 32767);
	}

	s->status = (gated ? NUDGE_ST_GATED : 0) | ((s->tilt_t > 0) ? NUDGE_ST_TILT : 0) |
	            (centering ? NUDGE_ST_CENTERING : 0) | (s->stored_zero ? NUDGE_ST_STORED_ZERO : 0);

	return (uint8_t)(was_tilt != (s->tilt_t > 0));
}

#endif
