/*
 * LWCloneU2
 * Copyright (C) 2013 Andreas Dittrich <lwcloneu2@cithraidt.de>
 *
 * This program is free software; you can redistribute it and/or modify it under the terms of the
 * GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program;
 * if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
 
#include <stdint.h>
#include <avr/interrupt.h>
#include <avr/io.h>
#include <avr/eeprom.h>
#include <util/atomic.h>

#include <hwconfig.h>
#include "led.h"
#include "panel.h"


#if !defined(LED_TIMER_vect)
	void led_init(void) {}
	void led_update(uint8_t *p8bytes) {}
	uint32_t led_get_on_mask(void) { return 0; }
#else


#define MAP(X, pin, inv) X##pin##_index,
enum { LED_MAPPING_TABLE(MAP) NUMBER_OF_LEDS };
#undef MAP

#define NUMBER_OF_BANKS   ((NUMBER_OF_LEDS + 7) / 8)
#define MAX_PWM 49


#if (NUMBER_OF_LEDS > 32)
	#error "number of led pins is bigger than 32!"
#endif


struct {
	volatile uint8_t enable;
	volatile uint8_t mode;
} g_LED[NUMBER_OF_BANKS * 8];

volatile uint16_t g_dt = 256;

static volatile uint32_t g_on_mask = 0;             // outputs with pwm > 0 (for the nudge gating)

uint32_t led_get_on_mask(void)
{
	uint32_t m;
	ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
	{
		m = g_on_mask;
	}
	return m;
}  // access is not atomic, but the read in the pwm loop is not critical


/* Coil protection (maximum on-time per output)
 *
 * Outputs selected in the mask are switched off by the firmware after they have been on
 * continuously for longer than the configured time. They stay off until the host switches
 * them off (SBA) and on again. Protects solenoids/motors if the PC software hangs.
 *
 * Configuration command (8 bytes, stored in EEPROM):
 *   67, mask0, mask1, mask2, mask3, time_lo, time_hi, check
 *   mask: bit 0 of mask0 = output 1 ... bit 7 of mask3 = output 32
 *   time: maximum on-time in units of 10 ms (0 = protection off, max. 655.35 s)
 *   check = 0x5A ^ mask0 ^ mask1 ^ mask2 ^ mask3 ^ time_lo ^ time_hi
 */
#define LWCCONFIG_CMD_COILPROT 67
#define COILPROT_MAGIC 0xC5

#if !defined(LED_EEPROM_ADDR)
#define LED_EEPROM_ADDR 0x80    // behind the config table of main_usb.c (28 bytes at 0x00)
#endif
#if !defined(COILPROT_DEFAULT_MASK)
#define COILPROT_DEFAULT_MASK 0UL   // default: no output protected
#endif
#if !defined(COILPROT_DEFAULT_TIME10MS)
#define COILPROT_DEFAULT_TIME10MS 0
#endif

typedef struct {
	uint8_t magic;
	uint8_t mask[4];
	uint8_t time_lo;
	uint8_t time_hi;
	uint8_t check;
} coilprot_cfg_t;

static uint8_t g_prot[NUMBER_OF_BANKS * 8];          // 1 = output is protected
static uint8_t g_blocked[NUMBER_OF_BANKS * 8];       // 1 = switched off by the protection
static uint16_t g_on_ticks[NUMBER_OF_BANKS * 8];     // on-time in pwm periods (~9.8 ms)
static volatile uint16_t g_prot_ticks = 0;           // limit in pwm periods, 0 = off

static uint16_t g_prot_time10ms = 0;                 // configured time, needed again when the pwm frequency changes

static void coilprot_apply(const uint8_t *mask4, uint16_t time10ms);
static void coilprot_load(void);


/* Adjustable PWM frequency
 *
 * Command (8 bytes, stored in EEPROM):  68, code, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, ~code
 *   code = frequency / 5 Hz  (20 = 100 Hz = default ... 80 = 400 Hz)
 * The frequency is limited per board (LED_PWM_MAX_HZ in hwconfig.h).
 * Effect speeds (blink/breathe) and the coil protection time stay the same.
 */
#define LWCCONFIG_CMD_PWMFREQ 68
#define PWMFREQ_MAGIC 0xA8

#if !defined(LED_PWM_MAX_HZ)
#define LED_PWM_MAX_HZ 100
#endif

#define PWM_TIMER_HZ   (F_CPU / 64UL)       // 250 kHz timer clock
#define PWM_DEFAULT_OCR 49                  // original LWCloneU2: 200 us -> ~102 Hz

static uint8_t g_pwm_ocr = PWM_DEFAULT_OCR;
static volatile uint16_t g_t_mul = 256;    // effect time base compensation (256 = 1.0)

static void pwmfreq_apply(uint8_t code);
static void pwmfreq_load(void);


static void update_state(uint8_t * p5bytes);
static void update_profile(int8_t k, uint8_t * p8bytes);
static void update_pwm(uint8_t *pwm, int8_t n, uint16_t t);
static void led_ports_init(void);



void led_init(void)
{
	/* LED driver */
	led_ports_init();

	// coil protection settings from EEPROM
	coilprot_load();

	// Timer for soft-PWM
	led_timer_init();

	// PWM frequency from EEPROM (after the timer init, it changes the compare value)
	pwmfreq_load();
}


static void coilprot_set_ticks(void)
{
	// one pwm period = MAX_PWM timer cycles of (OCR+1) * 4 us; ticks = time / period
	uint32_t const period_us = (uint32_t)(g_pwm_ocr + 1) * (1000000UL / PWM_TIMER_HZ) * MAX_PWM;
	uint32_t ticks = ((uint32_t)g_prot_time10ms * 10000UL + period_us / 2) / period_us;
	if (ticks > 0xFFFF) ticks = 0xFFFF;
	if (g_prot_time10ms > 0 && ticks == 0) ticks = 1;

	ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
	{
		g_prot_ticks = (uint16_t)ticks;
	}
}


static void pwmfreq_apply(uint8_t code)
{
	uint16_t hz = (uint16_t)code * 5;
	if (hz < 100) hz = 100;
	if (hz > LED_PWM_MAX_HZ) hz = LED_PWM_MAX_HZ;

	uint8_t ocr = PWM_DEFAULT_OCR;
	if (hz > 100)
	{
		uint32_t v = (PWM_TIMER_HZ + (uint32_t)MAX_PWM * hz / 2) / ((uint32_t)MAX_PWM * hz);
		ocr = (v > 1) ? (uint8_t)(v - 1) : 1;
	}

	g_pwm_ocr = ocr;

	#if defined(LED_PWM_SET_OCR)
	ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
	{
		LED_PWM_SET_OCR(ocr);
		// shorter period -> advance the effect time proportionally slower
		g_t_mul = (uint16_t)((256UL * (ocr + 1) + (PWM_DEFAULT_OCR + 1) / 2) / (PWM_DEFAULT_OCR + 1));
	}
	#endif

	coilprot_set_ticks();
}


static void pwmfreq_load(void)
{
	uint8_t cfg[3];
	eeprom_read_block((void*)cfg, (const void*)(LED_EEPROM_ADDR + 8), sizeof(cfg));

	if (cfg[0] == PWMFREQ_MAGIC && cfg[2] == (uint8_t)~cfg[1])
		pwmfreq_apply(cfg[1]);
	else
		pwmfreq_apply(20);
}


static void pwmfreq_config(uint8_t *p8bytes)
{
	if (p8bytes[2] != 0xFF || p8bytes[3] != 0xFF || p8bytes[4] != 0xFF ||
	    p8bytes[5] != 0xFF || p8bytes[6] != 0xFF || p8bytes[7] != (uint8_t)~p8bytes[1])
		return;

	uint8_t code = p8bytes[1];
	pwmfreq_apply(code);

	uint8_t cfg[3] = { PWMFREQ_MAGIC, code, (uint8_t)~code };
	eeprom_update_block((const void*)cfg, (void*)(LED_EEPROM_ADDR + 8), sizeof(cfg));
}


static uint8_t coilprot_check(const uint8_t *mask4, uint8_t lo, uint8_t hi)
{
	return 0x5A ^ mask4[0] ^ mask4[1] ^ mask4[2] ^ mask4[3] ^ lo ^ hi;
}


static void coilprot_apply(const uint8_t *mask4, uint16_t time10ms)
{
	ATOMIC_BLOCK(ATOMIC_RESTORESTATE)   // keeps the interrupt state (led_init runs before sei())
	{
		for (uint8_t i = 0; i < sizeof(g_prot); i++)
		{
			g_prot[i] = (i < 32) ? ((mask4[i >> 3] >> (i & 7)) & 0x01) : 0;
			g_blocked[i] = 0;
			g_on_ticks[i] = 0;
		}
	}

	g_prot_time10ms = time10ms;
	coilprot_set_ticks();
}


static void coilprot_load(void)
{
	coilprot_cfg_t cfg;
	eeprom_read_block((void*)&cfg, (const void*)LED_EEPROM_ADDR, sizeof(cfg));

	if (cfg.magic == COILPROT_MAGIC &&
	    cfg.check == coilprot_check(cfg.mask, cfg.time_lo, cfg.time_hi))
	{
		coilprot_apply(cfg.mask, ((uint16_t)cfg.time_hi << 8) | cfg.time_lo);
	}
	else
	{
		uint8_t m[4];
		m[0] = (uint8_t)(COILPROT_DEFAULT_MASK);
		m[1] = (uint8_t)(COILPROT_DEFAULT_MASK >> 8);
		m[2] = (uint8_t)(COILPROT_DEFAULT_MASK >> 16);
		m[3] = (uint8_t)(COILPROT_DEFAULT_MASK >> 24);
		coilprot_apply(m, COILPROT_DEFAULT_TIME10MS);
	}
}


static void coilprot_config(uint8_t *p8bytes)
{
	if (p8bytes[7] != coilprot_check(&p8bytes[1], p8bytes[5], p8bytes[6]))
		return;

	coilprot_cfg_t cfg;
	cfg.magic = COILPROT_MAGIC;
	cfg.mask[0] = p8bytes[1];
	cfg.mask[1] = p8bytes[2];
	cfg.mask[2] = p8bytes[3];
	cfg.mask[3] = p8bytes[4];
	cfg.time_lo = p8bytes[5];
	cfg.time_hi = p8bytes[6];
	cfg.check = p8bytes[7];

	coilprot_apply(cfg.mask, ((uint16_t)cfg.time_hi << 8) | cfg.time_lo);
	eeprom_update_block((const void*)&cfg, (void*)LED_EEPROM_ADDR, sizeof(cfg));
}


void led_update(uint8_t *p8bytes)
{
	static uint8_t nbank = 0;

	#if (USE_ACCELGYRO)
	if (p8bytes[0] == 69)
	{
		// nudge configuration, handled by the panel code (valid PBA values are 0..49, 129..132)
		panel_nudge_config(p8bytes);
		return;
	}
	#endif

	if (p8bytes[0] == LWCCONFIG_CMD_PWMFREQ)
	{
		pwmfreq_config(p8bytes);
		return;
	}

	if (p8bytes[0] == LWCCONFIG_CMD_COILPROT)
	{
		// configuration command, never a brightness profile (valid PBA values are 0..49, 129..132)
		coilprot_config(p8bytes);
		return;
	}

	if (p8bytes[0] == 64)
	{
		update_state(p8bytes + 1);
		nbank = 0;
	}
	else
	{
		update_profile(nbank, p8bytes);
		nbank = (nbank + 1) & 0x03;
	}
}


static void update_state(uint8_t * p5bytes)
{
	for (int8_t k = 0; k < NUMBER_OF_BANKS; k++)
	{
		uint8_t b = p5bytes[k];

		for (int8_t i = 0; i < 8; i++)
		{
			g_LED[k * 8 + i].enable = b & 0x01;
			b >>= 1;
		}
	}

	uint8_t pulse_speed = p5bytes[4];

	if (pulse_speed > 7)
	    pulse_speed = 7;

	if (pulse_speed == 0)
	    pulse_speed = 1;

	g_dt = pulse_speed * 128;
}


static void update_profile(int8_t k, uint8_t * p8bytes)
{
	if (k >= NUMBER_OF_BANKS)
		return;

	for (int8_t i = 0; i < 8; i++)
	{
		g_LED[k * 8 + i].mode = p8bytes[i];
	}
}


static void update_pwm(uint8_t *pwm, int8_t n, uint16_t t)
{
	uint16_t const limit = g_prot_ticks;
	uint32_t on_mask = 0;

	for (int8_t i = 0; i < n; i++) 
	{
		if (g_LED[i].enable == 0)
		{
			pwm[i] = 0;
			g_on_ticks[i] = 0;
			g_blocked[i] = 0;    // host switched it off: protection re-armed
		}
		else if (limit != 0 && g_prot[i] && (g_blocked[i] || ++g_on_ticks[i] >= limit))
		{
			pwm[i] = 0;          // on for too long: keep off until the host switches it off
			g_blocked[i] = 1;
		}
		else
		{
			uint8_t b = g_LED[i].mode;

			if ((b >= 0) && (b <= MAX_PWM))
			{
				// constant brightness

				pwm[i] = b;
			}
			else if (b == 129)
			{
				// triangle

				uint16_t x = t >> 8;
				if (x & 0x80) // 128..255
					x = 255 - x;

				pwm[i] = (MAX_PWM * x) >> 7;

			}
			else if (b == 130)
			{
				// rect
				
				pwm[i] = (t & 0x8000) ? MAX_PWM : 0;
			}
			else if (b == 131)
			{
				// fall

				uint16_t x = 255 - (t >> 8);

				pwm[i] = (MAX_PWM * x) >> 8;
			}
			else if (b == 132)
			{
				// rise

				uint16_t x = t >> 8;

				pwm[i] = (MAX_PWM * x) >> 8;
			}
			else
			{
				// unexpected!

				pwm[i] = 0;
			}
		}

		if (pwm[i] != 0 && i < 32)
			on_mask |= (1UL << i);
	}

	g_on_mask = on_mask;    // runs in the timer ISR
}


ISR(LED_TIMER_vect)
{
	#if defined(ENABLE_PROFILING)
	profile_start();
	#endif

	static int8_t counter = 0;
	static uint16_t t = 0;
	static uint8_t pwm[NUMBER_OF_LEDS];

	counter--;

	if (counter < 0)
	{
		// reset counter
		counter = MAX_PWM - 1; // pwm value of MAX_PWM should be allways 'on', 0 should be allways 'off'

		// increment time counter
		t += (uint16_t)(((uint32_t)g_dt * g_t_mul) >> 8);   // effect speed independent of the pwm frequency

		// update pwm values
		update_pwm(pwm, sizeof(pwm) / sizeof(pwm[0]), t);
	}

	// set or clear all defined pins

	#define MAP(X, pin, inv) if ((pwm[X##pin##_index] > counter) == (!inv)) { PORT##X |= (1 << pin); } else { PORT##X &= ~(1 << pin); }
	LED_MAPPING_TABLE(MAP)
	#undef MAP
}


static void led_ports_init(void)
{
	#define MAP(X, pin, inv) \
		PORT##X &= ~(1 << pin); \
		DDR##X  |= (1 << pin);
	LED_MAPPING_TABLE(MAP)
	#undef MAP
}

#endif
