/*
 * LWCloneU2 Resurrected VERSUS Rev 0.4b - Konfiguration
 * 2-Spieler-Tastatur-Encoder fuer MAME: 32 Taster ueber 4 x 74HC165 am Pro Micro (ATmega32U4).
 * Meldet sich als USB-Tastatur mit N-Key-Rollover (jede Taste einzeln, beliebig viele gleichzeitig).
 * GPL-2.0, Designed by Frischbrot in 2026
 *
 * Anschluss der 74HC165 (je Chip eigene Leitungen, alle vier werden gleichzeitig gelesen):
 *   Chip A (oben links)   PL = A3 (PF4)  CP = A2 (PF5)  Q7 = A1 (PF6)
 *   Chip B (oben rechts)  PL = A0 (PF7)  CP = D16 (PB2) Q7 = D10 (PB6)
 *   Chip C (unten rechts) PL = D5 (PC6)  CP = D4 (PD4)  Q7 = D3 (PD0)
 *   Chip D (unten links)  PL = D2 (PD1)  CP = RX (PD2)  Q7 = TX (PD3)
 */
#ifndef DEVCONFIG_H__INCLUDED
#define DEVCONFIG_H__INCLUDED

#define USB_PRODUCT_STRING  "LWCloneU2 Resurrected VERSUS Rev 0.4b"
#define USB_VENDOR_ID       0xFAFA      /* PID ausserhalb der LED-Wiz-IDs 0x00F0-0x00FF: DOF/LEDBlinky ignorieren das Board */
#define USB_PRODUCT_ID      0x0101

/* Entprellung: eine Aenderung wird sofort gemeldet, danach wird dieser Taster fuer DEBOUNCE_MS gesperrt.
   Damit kostet das Entprellen keine Verzoegerung. */
#if !defined(DEBOUNCE_MS)
#define DEBOUNCE_MS         5
#endif

#endif
