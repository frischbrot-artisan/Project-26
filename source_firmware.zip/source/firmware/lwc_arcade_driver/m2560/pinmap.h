/*
 * LWCloneU2
 * Copyright (C) 2013 Andreas Dittrich <lwcloneu2@cithraidt.de>
 *
 * This program is free software; you can redistribute it and/or modify it under the terms of the
 * GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program;
 * if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

/*
 * Pin map for the "LWCloneU2 Resurrected ARCADE" shield Rev 0.4b (Arduino Mega 2560 R3).
 * The order of LED_MAPPING_TABLE defines the LED-Wiz / DOF output numbers 1..32,
 * exactly as printed on the shield.
 *
 * The ARCADE board has no MOSFETs: all 32 outputs are ULN2803 outputs (0.5 A each, 4 chips).
 * The pin order follows the compact board layout (straight traces through the Mega header gaps):
 *   1-16  ULN2803 U3/U4,  D37, D36 ... D22 (descending), terminals J8-J15 (top edge, left to right)
 *  17-32  ULN2803 U1/U2,  D38, D39 ... D53 (ascending),  terminals J16-J23 (bottom edge, left to right)
 *
 * Inputs (PANEL_MAPPING_TABLE): 32 arcade buttons on D2-D17, D20, D21, A0, A1, A4-A15 (switch to GND,
 * internal pull-ups), terminal labels as printed on the ARCADE board. The functions are assigned so that the input column
 * reads top to bottom: P1 (up, down, left, right, B1-B6, start, coin), P2 (same), menu/exit/pause/service/tilt/spares.
 * D6 (P1 START) is the shift button.
 * No accelerometer on the ARCADE board: A2 and A3 are not used.
 */

#define LED_MAPPING_TABLE(_map_) \
	\
	_map_( C, 0, 0 ) /*  1  D37  ULN2803 (U3/U4, top edge) */ \
	_map_( C, 1, 0 ) /*  2  D36  ULN2803 (U3/U4, top edge) */ \
	_map_( C, 2, 0 ) /*  3  D35  ULN2803 (U3/U4, top edge) */ \
	_map_( C, 3, 0 ) /*  4  D34  ULN2803 (U3/U4, top edge) */ \
	_map_( C, 4, 0 ) /*  5  D33  ULN2803 (U3/U4, top edge) */ \
	_map_( C, 5, 0 ) /*  6  D32  ULN2803 (U3/U4, top edge) */ \
	_map_( C, 6, 0 ) /*  7  D31  ULN2803 (U3/U4, top edge) */ \
	_map_( C, 7, 0 ) /*  8  D30  ULN2803 (U3/U4, top edge) */ \
	_map_( A, 7, 0 ) /*  9  D29  ULN2803 (U3/U4, top edge) */ \
	_map_( A, 6, 0 ) /* 10  D28  ULN2803 (U3/U4, top edge) */ \
	_map_( A, 5, 0 ) /* 11  D27  ULN2803 (U3/U4, top edge) */ \
	_map_( A, 4, 0 ) /* 12  D26  ULN2803 (U3/U4, top edge) */ \
	_map_( A, 3, 0 ) /* 13  D25  ULN2803 (U3/U4, top edge) */ \
	_map_( A, 2, 0 ) /* 14  D24  ULN2803 (U3/U4, top edge) */ \
	_map_( A, 1, 0 ) /* 15  D23  ULN2803 (U3/U4, top edge) */ \
	_map_( A, 0, 0 ) /* 16  D22  ULN2803 (U3/U4, top edge) */ \
	_map_( D, 7, 0 ) /* 17  D38  ULN2803 (U1/U2, bottom edge) */ \
	_map_( G, 2, 0 ) /* 18  D39  ULN2803 (U1/U2, bottom edge) */ \
	_map_( G, 1, 0 ) /* 19  D40  ULN2803 (U1/U2, bottom edge) */ \
	_map_( G, 0, 0 ) /* 20  D41  ULN2803 (U1/U2, bottom edge) */ \
	_map_( L, 7, 0 ) /* 21  D42  ULN2803 (U1/U2, bottom edge) */ \
	_map_( L, 6, 0 ) /* 22  D43  ULN2803 (U1/U2, bottom edge) */ \
	_map_( L, 5, 0 ) /* 23  D44  ULN2803 (U1/U2, bottom edge) */ \
	_map_( L, 4, 0 ) /* 24  D45  ULN2803 (U1/U2, bottom edge) */ \
	_map_( L, 3, 0 ) /* 25  D46  ULN2803 (U1/U2, bottom edge) */ \
	_map_( L, 2, 0 ) /* 26  D47  ULN2803 (U1/U2, bottom edge) */ \
	_map_( L, 1, 0 ) /* 27  D48  ULN2803 (U1/U2, bottom edge) */ \
	_map_( L, 0, 0 ) /* 28  D49  ULN2803 (U1/U2, bottom edge) */ \
	_map_( B, 3, 0 ) /* 29  D50  ULN2803 (U1/U2, bottom edge) */ \
	_map_( B, 2, 0 ) /* 30  D51  ULN2803 (U1/U2, bottom edge) */ \
	_map_( B, 1, 0 ) /* 31  D52  ULN2803 (U1/U2, bottom edge) */ \
	_map_( B, 0, 0 ) /* 32  D53  ULN2803 (U1/U2, bottom edge) */ \
	\
	/* end */

#if (USE_MOUSE)
#define MOUSE_X_CLK_INDEX    9
#define MOUSE_X_DIR_INDEX   10
#define MOUSE_Y_CLK_INDEX   11
#define MOUSE_Y_DIR_INDEX   12
#endif

/* ARCADE: 2 players, MAME default keys (US key positions, work with any Windows keyboard layout,
 * because MAME reads key positions). P1 START is also the SHIFT button:
 * tap it alone -> "1", hold it + other input -> second function (right column). */
#define SHIFT_SWITCH_INDEX   4
#define SHIFT_SWITCH_TAP     1

#define PANEL_MAPPING_TABLE(_map_) \
	\
	_map_( E, 4,    KEY_Space        ,KEY_Space         ) /* D2   P1 B3     Space */ \
	_map_( E, 5,    MOD_LeftShift    ,MOD_LeftShift     ) /* D3   P1 B4     Left Shift */ \
	_map_( G, 5,    KEY_Z            ,KEY_Z             ) /* D4   P1 B5     Z */ \
	_map_( E, 3,    KEY_X            ,KEY_X             ) /* D5   P1 B6     X */ \
	_map_( H, 3,    KEY_1            ,0                 ) /* D6   P1 START  1 (start 1)         = SHIFT button (tap: 1) */ \
	_map_( H, 4,    KEY_5            ,AC_Mute           ) /* D7   P1 COIN   5 (coin 1)          shift: mute */ \
	_map_( H, 5,    KEY_DownArrow    ,AC_VolumeDown     ) /* D8   P1 DOWN   Down arrow          shift: volume - */ \
	_map_( H, 6,    KEY_R            ,KEY_R             ) /* D9   P2 UP     R */ \
	_map_( B, 4,    KEY_F            ,KEY_F             ) /* D10  P2 DOWN   F */ \
	_map_( B, 5,    KEY_D            ,KEY_D             ) /* D11  P2 LEFT   D */ \
	_map_( B, 6,    KEY_G            ,KEY_G             ) /* D12  P2 RIGHT  G */ \
	_map_( B, 7,    KEY_A            ,KEY_A             ) /* D13  P2 B1     A */ \
	_map_( J, 1,    KEY_LeftArrow    ,KEY_Enter         ) /* D14  P1 LEFT   Left arrow          shift: Enter */ \
	_map_( J, 0,    KEY_RightArrow   ,KEY_Tab           ) /* D15  P1 RIGHT  Right arrow         shift: Tab */ \
	_map_( H, 1,    MOD_LeftControl  ,MOD_LeftControl   ) /* D16  P1 B1     Left Ctrl */ \
	_map_( H, 0,    MOD_LeftAlt      ,MOD_LeftAlt       ) /* D17  P1 B2     Left Alt */ \
	_map_( D, 1,    KEY_S            ,KEY_S             ) /* D20  P2 B2     S */ \
	_map_( D, 0,    KEY_UpArrow      ,AC_VolumeUp       ) /* D21  P1 UP     Up arrow            shift: volume + */ \
	_map_( F, 0,    KEY_Q            ,KEY_Q             ) /* A0   P2 B3     Q */ \
	_map_( F, 1,    KEY_W            ,KEY_W             ) /* A1   P2 B4     W */ \
	_map_( F, 4,    KEY_I            ,KEY_I             ) /* A4   P2 B5     I (no MAME default, assign once) */ \
	_map_( F, 5,    KEY_K            ,KEY_K             ) /* A5   P2 B6     K (no MAME default, assign once) */ \
	_map_( F, 6,    KEY_2            ,KEY_Esc           ) /* A6   P2 START  2 (start 2)         shift: Esc */ \
	_map_( F, 7,    KEY_6            ,KEY_6             ) /* A7   P2 COIN   6 (coin 2) */ \
	_map_( K, 0,    KEY_B            ,KEY_B             ) /* A8   SPARE 3   B (MAME P1 button 9) */ \
	_map_( K, 1,    KEY_V            ,KEY_V             ) /* A9   SPARE 2   V (MAME P1 button 8) */ \
	_map_( K, 2,    KEY_C            ,KEY_C             ) /* A10  SPARE 1   C (MAME P1 button 7) */ \
	_map_( K, 3,    KEY_T            ,KEY_T             ) /* A11  TILT      T */ \
	_map_( K, 4,    KEY_9            ,KEY_9             ) /* A12  SERVICE   9 (service 1) */ \
	_map_( K, 5,    KEY_P            ,KEY_P             ) /* A13  PAUSE     P */ \
	_map_( K, 6,    KEY_Esc          ,KEY_Esc           ) /* A14  EXIT      Esc */ \
	_map_( K, 7,    KEY_Tab          ,KEY_Tab           ) /* A15  MENU      Tab (MAME menu) */ \
	\
	/* end */


/* no ADC_MAPPING_TABLE: the ARCADE board has no accelerometer, A2 and A3 are not used */
