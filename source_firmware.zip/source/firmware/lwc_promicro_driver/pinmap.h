/*
 * LWCloneU2 - pin map for the Pro Micro boards LWCloneU2 Resurrected DUO / SLIM / FORCE (Rev 0.4b)
 * (8x MOSFET low-side outputs + 8x ULN2803 outputs, 16 status LEDs)
 *
 * The order of the lines below defines the LED-Wiz / DOF output numbers 1..16.
 * These numbers are printed on the board next to the terminals.
 *
 *  out  board terminal   Pro Micro pin   AVR port
 *   1   J3-1  (MOSFET Q1)     A3            PF4
 *   2   J3-2  (MOSFET Q2)     A2            PF5
 *   3   J4-1  (MOSFET Q3)     A1            PF6
 *   4   J4-2  (MOSFET Q4)     A0            PF7
 *   5   J5-1  (MOSFET Q5)     D15 (SCK)     PB1
 *   6   J5-2  (MOSFET Q6)     D14 (MISO)    PB3
 *   7   J6-1  (MOSFET Q7)     D16 (MOSI)    PB2
 *   8   J6-2  (MOSFET Q8)     D10           PB6
 *   9   J7-1  (ULN2803 ch1)   D2            PD1
 *  10   J7-2  (ULN2803 ch2)   D3            PD0
 *  11   J8-1  (ULN2803 ch3)   D4            PD4
 *  12   J8-2  (ULN2803 ch4)   D5            PC6
 *  13   J9-1  (ULN2803 ch5)   D6            PD7
 *  14   J9-2  (ULN2803 ch6)   D7            PE6
 *  15   J10-1 (ULN2803 ch7)   D8            PB4
 *  16   J10-2 (ULN2803 ch8)   D9            PB5
 *
 * third parameter: 0 = active high (output on = pin high) - correct for this board.
 */

#define LED_MAPPING_TABLE(_map_) \
	_map_( F, 4, 0 ) /*  1  A3  */ \
	_map_( F, 5, 0 ) /*  2  A2  */ \
	_map_( F, 6, 0 ) /*  3  A1  */ \
	_map_( F, 7, 0 ) /*  4  A0  */ \
	_map_( B, 1, 0 ) /*  5  D15 */ \
	_map_( B, 3, 0 ) /*  6  D14 */ \
	_map_( B, 2, 0 ) /*  7  D16 */ \
	_map_( B, 6, 0 ) /*  8  D10 */ \
	_map_( D, 1, 0 ) /*  9  D2  */ \
	_map_( D, 0, 0 ) /* 10  D3  */ \
	_map_( D, 4, 0 ) /* 11  D4  */ \
	_map_( C, 6, 0 ) /* 12  D5  */ \
	_map_( D, 7, 0 ) /* 13  D6  */ \
	_map_( E, 6, 0 ) /* 14  D7  */ \
	_map_( B, 4, 0 ) /* 15  D8  */ \
	_map_( B, 5, 0 ) /* 16  D9  */ \
	/* end */

/* no panel (joystick/keyboard/mouse) inputs and no analog inputs on this board */
#define PANEL_MAPPING_TABLE(_map_)
