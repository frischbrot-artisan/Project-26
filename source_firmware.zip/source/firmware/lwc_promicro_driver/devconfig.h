/*
 * LWCloneU2 - device config for the Pro Micro boards (Rev 0.4b):
 *   LWCloneU2 Resurrected DUO   - 8 x MOSFET + 8 x ULN2803   (default)
 *   LWCloneU2 Resurrected SLIM  - 16 x ULN2803               (make LWC_DEFS=-DLWC_BOARD_SLIM)
 *   LWCloneU2 Resurrected FORCE - 16 x MOSFET                (make LWC_DEFS=-DLWC_BOARD_FORCE)
 * All three boards use the same pins; only the USB product string differs,
 * so the LWCloneU2 Resurrected Tool can show the correct output types.
 * LED-Wiz device only: no joystick, keyboard, mouse or analog inputs
 * (all usable pins are outputs).
 */
#ifndef DEVCONFIG_H__INCLUDED
#define DEVCONFIG_H__INCLUDED

#define ENABLE_LED_DEVICE
#define NUM_JOYSTICKS 0
#define USE_MOUSE 0
#define USE_CONSUMER 0
#define USE_KEYBOARD 0

/* PF4..PF7 (outputs 1-4) share the JTAG pins: make sure JTAG is off at runtime */
#define HW_DISABLE_JTAG

/* board identification, read by the LWCloneU2 Resurrected Tool */
#if defined(LWC_BOARD_SLIM)
#define USB_PRODUCT_STRING "LWCloneU2 Resurrected SLIM Rev 0.4b"
#elif defined(LWC_BOARD_FORCE)
#define USB_PRODUCT_STRING "LWCloneU2 Resurrected FORCE Rev 0.4b"
#else
#define USB_PRODUCT_STRING "LWCloneU2 Resurrected DUO Rev 0.4b"
#endif

/* default LED-Wiz ID 1 (0x00F0 = ID 1 ... 0x00FF = ID 16), changeable with the LWCloneU2 Resurrected Tool */
#define USB_PRODUCT_ID 0x00F0

/* coil protection (maximum on-time), normally set with the LWCloneU2 Resurrected Tool and stored in EEPROM.
   These defaults are only used as long as nothing was stored. Example: MOSFET outputs 1-8, 2 s:
   #define COILPROT_DEFAULT_MASK     0x000000FFUL
   #define COILPROT_DEFAULT_TIME10MS 200                                                          */

#endif
