/*
 * VERSUS - USB-Deskriptoren (LUFA 130901)
 * Aufbau nach dem Muster von descriptors.c (LWCloneU2, Andreas Dittrich) und den LUFA-Demos (Dean Camera).
 * GPL-2.0, Designed by Frischbrot in 2026
 */
#include "versus_descriptors.h"

#define XYZ_TO_BCD(a,b,c) \
	((uint16_t)(((a)/10) % 10) << 12) | \
	((uint16_t)((a) % 10) << 8) | \
	((uint16_t)((b) % 10) << 4) | \
	((uint16_t)((c) % 10) << 0)

#define USB_WIDEN2(x) L##x
#define USB_WIDEN(x) USB_WIDEN2(x)

#define USB_STRING_TABLE(_map_) \
	_map_(ManufacturerString_id,  "Frischbrot") \
	_map_(ProductString_id,       USB_PRODUCT_STRING)

typedef enum {
	LanguageString_id = 0,
	#define MAP(x, y) x,
	USB_STRING_TABLE(MAP)
	#undef MAP
} UsbStringsEnum;

static const USB_Descriptor_String_t PROGMEM LanguageString =
{
	.Header                 = {.Size = USB_STRING_LEN(1), .Type = DTYPE_String},
	.UnicodeString          = {LANGUAGE_ID_ENG}
};

#define MAP(name, str) \
static const USB_Descriptor_String_t PROGMEM name##__str_ = \
{ \
	.Header                 = {.Size = USB_STRING_LEN(sizeof(str) - 1), .Type = DTYPE_String}, \
	.UnicodeString          = USB_WIDEN(str) \
};
USB_STRING_TABLE(MAP)
#undef MAP

/* Report 1: Tastatur mit N-Key-Rollover (8 Modifier-Bits + Bitfeld fuer die Usages 0x00..0x6F), Report 2: Lautstaerke */
static const USB_Descriptor_HIDReport_Datatype_t PROGMEM KeyboardReport[] =
{
	0x05, 0x01,        /* USAGE_PAGE (Generic Desktop) */
	0x09, 0x06,        /* USAGE (Keyboard) */
	0xa1, 0x01,        /* COLLECTION (Application) */
	0x85, 0x01,        /*   REPORT_ID (1) */
	0x05, 0x07,        /*   USAGE_PAGE (Keyboard) */
	0x19, 0xe0,        /*   USAGE_MINIMUM (Left Control) */
	0x29, 0xe7,        /*   USAGE_MAXIMUM (Right GUI) */
	0x15, 0x00,        /*   LOGICAL_MINIMUM (0) */
	0x25, 0x01,        /*   LOGICAL_MAXIMUM (1) */
	0x75, 0x01,        /*   REPORT_SIZE (1) */
	0x95, 0x08,        /*   REPORT_COUNT (8) */
	0x81, 0x02,        /*   INPUT (Data,Var,Abs) */
	0x19, 0x00,        /*   USAGE_MINIMUM (0) */
	0x29, 0x6f,        /*   USAGE_MAXIMUM (0x6F) */
	0x95, 0x70,        /*   REPORT_COUNT (112) */
	0x81, 0x02,        /*   INPUT (Data,Var,Abs) */
	0xc0,              /* END_COLLECTION */
	/* Lautstaerke / Ton aus (Shift-Funktionen) */
	0x05, 0x0c,        /* USAGE_PAGE (Consumer Devices) */
	0x09, 0x01,        /* USAGE (Consumer Control) */
	0xa1, 0x01,        /* COLLECTION (Application) */
	0x85, 0x02,        /*   REPORT_ID (2) */
	0x15, 0x00,        /*   LOGICAL_MINIMUM (0) */
	0x25, 0x01,        /*   LOGICAL_MAXIMUM (1) */
	0x75, 0x01,        /*   REPORT_SIZE (1) */
	0x95, 0x03,        /*   REPORT_COUNT (3) */
	0x09, 0xe2,        /*   USAGE (Mute) */
	0x09, 0xe9,        /*   USAGE (Volume Increment) */
	0x09, 0xea,        /*   USAGE (Volume Decrement) */
	0x81, 0x02,        /*   INPUT (Data,Var,Abs) */
	0x95, 0x05,        /*   REPORT_COUNT (5) */
	0x81, 0x03,        /*   INPUT (Cnst,Var,Abs) */
	0xc0               /* END_COLLECTION */
};

static const USB_Descriptor_Device_t PROGMEM DeviceDescriptor =
{
	.Header                 = {.Size = sizeof(USB_Descriptor_Device_t), .Type = DTYPE_Device},
	.USBSpecification       = XYZ_TO_BCD(1,1,0),
	.Class                  = USB_CSCP_NoDeviceClass,
	.SubClass               = USB_CSCP_NoDeviceSubclass,
	.Protocol               = USB_CSCP_NoDeviceProtocol,
	.Endpoint0Size          = FIXED_CONTROL_ENDPOINT_SIZE,
	.VendorID               = USB_VENDOR_ID,
	.ProductID              = USB_PRODUCT_ID,
	.ReleaseNumber          = XYZ_TO_BCD(0,4,0),
	.ManufacturerStrIndex   = ManufacturerString_id,
	.ProductStrIndex        = ProductString_id,
	.SerialNumStrIndex      = NO_DESCRIPTOR,
	.NumberOfConfigurations = FIXED_NUM_CONFIGURATIONS
};

#define IFACENUMBER_KBD 0

static const USB_Descriptor_Configuration_t PROGMEM ConfigurationDescriptor =
{
	.Config =
	{
		.Header                 = {.Size = sizeof(USB_Descriptor_Configuration_Header_t), .Type = DTYPE_Configuration},
		.TotalConfigurationSize = sizeof(USB_Descriptor_Configuration_t),
		.TotalInterfaces        = 1,
		.ConfigurationNumber    = 1,
		.ConfigurationStrIndex  = NO_DESCRIPTOR,
		.ConfigAttributes       = USB_CONFIG_ATTR_RESERVED,
		.MaxPowerConsumption    = USB_CONFIG_POWER_MA(100)
	},

	.HID_Interface =
	{
		.Header                 = {.Size = sizeof(USB_Descriptor_Interface_t), .Type = DTYPE_Interface},
		.InterfaceNumber        = IFACENUMBER_KBD,
		.AlternateSetting       = 0x00,
		.TotalEndpoints         = 1,
		.Class                  = HID_CSCP_HIDClass,
		.SubClass               = HID_CSCP_NonBootSubclass,
		.Protocol               = HID_CSCP_NonBootProtocol,
		.InterfaceStrIndex      = NO_DESCRIPTOR
	},

	.HID_KeyboardHID =
	{
		.Header                 = {.Size = sizeof(USB_HID_Descriptor_HID_t), .Type = HID_DTYPE_HID},
		.HIDSpec                = XYZ_TO_BCD(1,1,1),
		.CountryCode            = 0x00,
		.TotalReportDescriptors = 1,
		.HIDReportType          = HID_DTYPE_Report,
		.HIDReportLength        = sizeof(KeyboardReport)
	},

	.HID_ReportINEndpoint =
	{
		.Header                 = {.Size = sizeof(USB_Descriptor_Endpoint_t), .Type = DTYPE_Endpoint},
		.EndpointAddress        = KBD_EPADDR,
		.Attributes             = (EP_TYPE_INTERRUPT | ENDPOINT_ATTR_NO_SYNC | ENDPOINT_USAGE_DATA),
		.EndpointSize           = KBD_EPSIZE,
		.PollingIntervalMS      = KBD_INTERVAL_MS
	}
};

uint16_t CALLBACK_USB_GetDescriptor(
	const uint16_t wValue,
	const uint8_t wIndex,
	const void** const DescriptorAddress,
	uint8_t *const DescriptorMemorySpace)
{
	const uint8_t  DescriptorType   = (wValue >> 8);
	const uint8_t  DescriptorNumber = (wValue & 0xFF);

	uint8_t memspace;
	uint8_t * const pmemspace = (DescriptorMemorySpace != NULL) ? DescriptorMemorySpace : &memspace;

	*pmemspace = MEMSPACE_FLASH;

	const void* Address = NULL;
	uint16_t    Size    = NO_DESCRIPTOR;

	switch (DescriptorType)
	{
		case DTYPE_Device:
			Address = &DeviceDescriptor;
			Size    = sizeof(USB_Descriptor_Device_t);
			break;

		case DTYPE_Configuration:
			Address = &ConfigurationDescriptor;
			Size    = sizeof(USB_Descriptor_Configuration_t);
			break;

		case DTYPE_String:
			switch (DescriptorNumber)
			{
				case LanguageString_id:
					Address = &LanguageString;
					Size    = pgm_read_byte(&LanguageString.Header.Size);
					break;

				#define MAP(name, str) \
				case name: \
					Address = &name##__str_; \
					Size    = pgm_read_byte(&name##__str_.Header.Size); \
					break;
				USB_STRING_TABLE(MAP)
				#undef MAP
			}
			break;

		case HID_DTYPE_HID:
			if (wIndex == IFACENUMBER_KBD)
			{
				Address = &ConfigurationDescriptor.HID_KeyboardHID;
				Size    = sizeof(USB_HID_Descriptor_HID_t);
			}
			break;

		case HID_DTYPE_Report:
			if (wIndex == IFACENUMBER_KBD)
			{
				Address = &KeyboardReport;
				Size    = sizeof(KeyboardReport);
			}
			break;
	}

	*DescriptorAddress = Address;

	return Size;
}
