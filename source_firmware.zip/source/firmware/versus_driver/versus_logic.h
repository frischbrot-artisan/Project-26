/*
 * VERSUS - reine Logik (Entprellen, Shift-Funktionen, Reports), ohne Hardware: auch im Host-Test benutzt
 * GPL-2.0, Designed by Frischbrot in 2026
 *
 * Shift wie beim ARCADE-Board: P1 START (SHIFT_INDEX) ist die Shift-Taste.
 *  - allein gedrueckt und losgelassen: beim Loslassen 60 ms lang die eigene Taste ("1")
 *  - festhalten + anderer Taster: dessen zweite Funktion (SHIFTMAP), die eigene Taste entfaellt
 *  - die Funktion eines Tasters wird beim Druecken festgelegt; aendert sich der Shift-Zustand,
 *    werden gehaltene Taster mit zweiter Funktion losgelassen (erst erneutes Druecken zaehlt wieder)
 */
#ifndef VERSUS_LOGIC_H__INCLUDED
#define VERSUS_LOGIC_H__INCLUDED

#include <stdint.h>
#include <string.h>
#include "keymap.h"

#define NUM_INPUTS     32
#define KBD_REPORT_ID  1
#define CONS_REPORT_ID 2
#define KBD_REPORT_SIZE  16      /* Report-ID, 1 Byte Modifier (E0..E7), 14 Byte Bitfeld fuer Usage 0x00..0x6F */
#define CONS_REPORT_SIZE 2       /* Report-ID, Bit 0 Ton aus, Bit 1 Lauter, Bit 2 Leiser */
#define SHIFT_TAP_MS   60
#define U_MUTE  0xF0
#define U_VOLUP 0xF1
#define U_VOLDN 0xF2

typedef struct {
	uint32_t state;        /* entprellt, 1 = gedrueckt */
	uint32_t shifted;      /* beim Druecken war Shift gehalten */
	uint32_t suppressed;   /* bis zum Loslassen stumm (Shift-Wechsel) */
	uint8_t  lock[NUM_INPUTS];
	uint8_t  shift_used;
	uint8_t  tap;          /* 1 = Tipp-Taste wird gerade gesendet */
	uint16_t tap_end;
} vs_t;

#define VS_BIT(i) ((uint32_t)1 << (i))
static inline uint8_t vs_key(uint8_t i)   { return KEYMAP[i >> 3][i & 7]; }
static inline uint8_t vs_shift(uint8_t i) { return SHIFTMAP[i >> 3][i & 7]; }

/* rohe Eingaenge verarbeiten; elapsed = vergangene ms seit dem letzten Aufruf, now = ms-Zaehler */
static inline void vs_step(vs_t * const v, uint32_t const raw, uint8_t const elapsed, uint16_t const now)
{
	for (uint8_t i = 0; i < NUM_INPUTS; i++)
	{
		if (v->lock[i] > elapsed) v->lock[i] -= elapsed; else v->lock[i] = 0;
		uint32_t const m = VS_BIT(i);
		if (v->lock[i] != 0 || !((v->state ^ raw) & m)) continue;

		/* Aenderung sofort uebernehmen, danach DEBOUNCE_MS sperren */
		v->state ^= m;
		v->lock[i] = DEBOUNCE_MS;
		uint8_t const down = (v->state & m) ? 1 : 0;

		if (i == SHIFT_INDEX)
		{
			/* gehaltene Taster mit zweiter Funktion loslassen */
			for (uint8_t k = 0; k < NUM_INPUTS; k++)
				if (k != SHIFT_INDEX && (v->state & VS_BIT(k)) && vs_shift(k)) v->suppressed |= VS_BIT(k);
			if (down) v->shift_used = 0;
			else if (!v->shift_used) { v->tap = 1; v->tap_end = (uint16_t)(now + SHIFT_TAP_MS); }
		}
		else if (down)
		{
			if (v->state & VS_BIT(SHIFT_INDEX)) { v->shifted |= m; v->shift_used = 1; }
			else v->shifted &= ~m;
		}
		else
		{
			v->shifted &= ~m; v->suppressed &= ~m;
		}
	}
	if (v->tap && (int16_t)(now - v->tap_end) >= 0) v->tap = 0;
}

static inline void vs_put(uint8_t * const kbd, uint8_t * const cons, uint8_t const u)
{
	if (u == U_MUTE) cons[1] |= 1;
	else if (u == U_VOLUP) cons[1] |= 2;
	else if (u == U_VOLDN) cons[1] |= 4;
	else if (u >= 0xE0 && u <= 0xE7) kbd[1] |= (uint8_t)(1 << (u - 0xE0));
	else if (u < 0x70) kbd[2 + (u >> 3)] |= (uint8_t)(1 << (u & 7));
}

static inline void vs_reports(vs_t const * const v, uint8_t * const kbd, uint8_t * const cons)
{
	memset(kbd, 0, KBD_REPORT_SIZE); kbd[0] = KBD_REPORT_ID;
	memset(cons, 0, CONS_REPORT_SIZE); cons[0] = CONS_REPORT_ID;
	uint32_t const act = v->state & ~v->suppressed;
	for (uint8_t i = 0; i < NUM_INPUTS; i++)
	{
		if (i == SHIFT_INDEX || !(act & VS_BIT(i))) continue;
		uint8_t const u = ((v->shifted & VS_BIT(i)) && vs_shift(i)) ? vs_shift(i) : vs_key(i);
		vs_put(kbd, cons, u);
	}
	if (v->tap) vs_put(kbd, cons, vs_key(SHIFT_INDEX));
}

#endif
