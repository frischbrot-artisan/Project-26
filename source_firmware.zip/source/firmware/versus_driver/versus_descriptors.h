/*
 * VERSUS - USB-Deskriptoren (LUFA 130901)
 * Ein HID-Interface: Tastatur mit N-Key-Rollover (Bitfeld), Abfrage jede Millisekunde.
 * GPL-2.0, Designed by Frischbrot in 2026
 */
#ifndef VERSUS_DESCRIPTORS_H__INCLUDED
#define VERSUS_DESCRIPTORS_H__INCLUDED

#include <avr/pgmspace.h>
#include <LUFA/Drivers/USB/USB.h>
#include "devconfig.h"

typedef struct
{
	USB_Descriptor_Configuration_Header_t  Config;
	USB_Descriptor_Interface_t             HID_Interface;
	USB_HID_Descriptor_HID_t               HID_KeyboardHID;
	USB_Descriptor_Endpoint_t              HID_ReportINEndpoint;
} USB_Descriptor_Configuration_t;

#define KBD_EPADDR            (ENDPOINT_DIR_IN | 1)
#define KBD_EPSIZE            16
#define KBD_INTERVAL_MS       1

/* CALLBACK_USB_GetDescriptor() ist in LUFA/Drivers/USB/Core/Device.h deklariert */

#endif
