/*
 * VERSUS Rev 0.4b - 2-Spieler-Tastatur-Encoder fuer MAME (32 Taster, N-Key-Rollover, Shift-Funktionen)
 * Pro Micro (ATmega32U4, 16 MHz), LUFA 130901 (Dean Camera, www.lufa-lib.org)
 * GPL-2.0, Designed by Frischbrot in 2026
 *
 * Ablauf (Hauptschleife, ohne Wartezeiten):
 *  - alle vier 74HC165 gleichzeitig laden und mit 8 Takten auslesen (ca. 3 Mikrosekunden)
 *  - Entprellen ohne Verzoegerung: eine Aenderung gilt sofort, danach 5 ms Sperre fuer diesen Taster
 *  - Shift wie beim ARCADE: P1 START festhalten + Taster = zweite Funktion (Lautstaerke, Enter, Tab, Esc),
 *    P1 START allein = "1" (beim Loslassen)
 *  - bei jeder Aenderung sofort einen neuen Report bereitlegen; der PC holt ihn spaetestens nach 1 ms ab
 *  Gesamtlatenz Taster -> PC: unter 1,1 ms.
 */
#include <stdint.h>
#include <avr/io.h>
#include <avr/wdt.h>
#include <avr/power.h>
#include <avr/interrupt.h>
#include <util/atomic.h>
#include <LUFA/Drivers/USB/USB.h>

#include "devconfig.h"
#include "versus_logic.h"
#include "versus_descriptors.h"

static volatile uint16_t g_ms;           /* Millisekunden-Zaehler (Timer0) */
static vs_t g_vs;
static uint8_t g_kbd[KBD_REPORT_SIZE], g_cons[CONS_REPORT_SIZE];
static uint8_t g_kbd_pending = 1, g_cons_pending = 1;   /* Report muss (erneut) gesendet werden */
static uint8_t g_idle_count, g_protocol = 1;

/* --- Pins */
#define PLF ((1 << 4) | (1 << 7))        /* PL A, PL B */
#define PLC (1 << 6)                     /* PL C */
#define PLD (1 << 1)                     /* PL D */
#define CPF (1 << 5)                     /* CP A */
#define CPB (1 << 2)                     /* CP B */
#define CPD ((1 << 4) | (1 << 2))        /* CP C, CP D */
#define QF  (1 << 6)                     /* Q A */
#define QB  (1 << 6)                     /* Q B */
#define QDC (1 << 0)                     /* Q C */
#define QDD (1 << 3)                     /* Q D */

ISR(TIMER0_COMPA_vect) { g_ms++; }

static void hardware_init(void)
{
	MCUSR &= ~(1 << WDRF);
	wdt_disable();
	clock_prescale_set(clock_div_1);
	MCUCR = (1 << JTD); MCUCR = (1 << JTD);  /* JTAG aus, damit PF4-PF7 normale Pins sind (zweimal schreiben) */

	PORTF |= PLF;  PORTF &= ~CPF; DDRF |= PLF | CPF;  DDRF &= ~QF;  PORTF &= ~QF;
	PORTB &= ~CPB; DDRB |= CPB;   DDRB &= ~QB;  PORTB &= ~QB;
	PORTC |= PLC;  DDRC |= PLC;
	PORTD |= PLD;  PORTD &= ~CPD; DDRD |= PLD | CPD; DDRD &= ~(QDC | QDD); PORTD &= ~(QDC | QDD);
	DDRB |= (1 << 0); PORTB |= (1 << 0);     /* RX-LED (aktiv low): aus */
	DDRD |= (1 << 5); PORTD |= (1 << 5);     /* TX-LED (aktiv low): aus */

	TCCR0A = (1 << WGM01);                   /* CTC, 16 MHz / 64 / 250 = 1 kHz */
	TCCR0B = (1 << CS01) | (1 << CS00);
	OCR0A  = 249;
	TIMSK0 = (1 << OCIE0A);

	USB_Init();
}

/* alle vier Schieberegister lesen; Ergebnis: Bit (8 * Chip + n) = 1 wenn gedrueckt */
static uint32_t scan(void)
{
	uint8_t a = 0, b = 0, c = 0, d = 0;
	PORTF &= ~PLF; PORTC &= ~PLC; PORTD &= ~PLD;      /* parallel laden */
	__asm__ __volatile__ ("nop\n\tnop");
	PORTF |= PLF;  PORTC |= PLC;  PORTD |= PLD;
	__asm__ __volatile__ ("nop");
	for (uint8_t n = 0; n < 8; n++)
	{
		uint8_t const pf = PINF, pb = PINB, pd = PIND;
		/* Eingaenge sind aktiv low (Taster nach GND, Pull-up 10k) */
		if (!(pf & QF))  a |= (uint8_t)(1 << n);
		if (!(pb & QB))  b |= (uint8_t)(1 << n);
		if (!(pd & QDC)) c |= (uint8_t)(1 << n);
		if (!(pd & QDD)) d |= (uint8_t)(1 << n);
		PORTF |= CPF; PORTB |= CPB; PORTD |= CPD;     /* naechstes Bit */
		__asm__ __volatile__ ("nop");
		PORTF &= ~CPF; PORTB &= ~CPB; PORTD &= ~CPD;
	}
	return (uint32_t)a | ((uint32_t)b << 8) | ((uint32_t)c << 16) | ((uint32_t)d << 24);
}

static void keyboard_task(void)
{
	static uint16_t last_ms;
	uint16_t now;
	ATOMIC_BLOCK(ATOMIC_RESTORESTATE) { now = g_ms; }
	uint16_t d = (uint16_t)(now - last_ms);
	last_ms = now;

	vs_step(&g_vs, scan(), (uint8_t)(d > 255 ? 255 : d), now);

	uint8_t k[KBD_REPORT_SIZE], c[CONS_REPORT_SIZE];
	vs_reports(&g_vs, k, c);
	if (memcmp(k, g_kbd, sizeof(k))) { memcpy(g_kbd, k, sizeof(k)); g_kbd_pending = 1; }
	if (memcmp(c, g_cons, sizeof(c))) { memcpy(g_cons, c, sizeof(c)); g_cons_pending = 1; }
	if (g_vs.state) PORTB &= ~(1 << 0); else PORTB |= (1 << 0);     /* RX-LED: Taste gedrueckt */

	if (USB_DeviceState != DEVICE_STATE_Configured || !(g_kbd_pending || g_cons_pending))
		return;
	Endpoint_SelectEndpoint(KBD_EPADDR);
	if (!Endpoint_IsINReady())
		return;
	if (g_kbd_pending) { Endpoint_Write_Stream_LE(g_kbd, sizeof(g_kbd), NULL); g_kbd_pending = 0; }
	else               { Endpoint_Write_Stream_LE(g_cons, sizeof(g_cons), NULL); g_cons_pending = 0; }
	Endpoint_ClearIN();
}

int main(void)
{
	hardware_init();
	vs_reports(&g_vs, g_kbd, g_cons);
	GlobalInterruptEnable();
	for (;;)
	{
		keyboard_task();
		USB_USBTask();
	}
}

/* ------------------------------------------------------------------ USB-Ereignisse */

void EVENT_USB_Device_ConfigurationChanged(void)
{
	Endpoint_ConfigureEndpoint(KBD_EPADDR, EP_TYPE_INTERRUPT, KBD_EPSIZE, 1);
	g_kbd_pending = g_cons_pending = 1;
}

void EVENT_USB_Device_ControlRequest(void)
{
	switch (USB_ControlRequest.bRequest)
	{
	case HID_REQ_GetReport:
		if (USB_ControlRequest.bmRequestType == (REQDIR_DEVICETOHOST | REQTYPE_CLASS | REQREC_INTERFACE))
		{
			Endpoint_ClearSETUP();
			if ((USB_ControlRequest.wValue & 0xFF) == CONS_REPORT_ID) Endpoint_Write_Control_Stream_LE(g_cons, sizeof(g_cons));
			else Endpoint_Write_Control_Stream_LE(g_kbd, sizeof(g_kbd));
			Endpoint_ClearOUT();
		}
		break;

	case HID_REQ_SetReport:      /* LED-Report (NumLock usw.): annehmen und verwerfen */
		if (USB_ControlRequest.bmRequestType == (REQDIR_HOSTTODEVICE | REQTYPE_CLASS | REQREC_INTERFACE))
		{
			Endpoint_ClearSETUP();
			while (!(Endpoint_IsOUTReceived()))
			{
				if (USB_DeviceState == DEVICE_STATE_Unattached) return;
			}
			Endpoint_ClearOUT();
			Endpoint_ClearStatusStage();
		}
		break;

	case HID_REQ_SetIdle:
		if (USB_ControlRequest.bmRequestType == (REQDIR_HOSTTODEVICE | REQTYPE_CLASS | REQREC_INTERFACE))
		{
			Endpoint_ClearSETUP();
			Endpoint_ClearStatusStage();
			g_idle_count = (uint8_t)((USB_ControlRequest.wValue & 0xFF00) >> 8);
		}
		break;

	case HID_REQ_GetIdle:
		if (USB_ControlRequest.bmRequestType == (REQDIR_DEVICETOHOST | REQTYPE_CLASS | REQREC_INTERFACE))
		{
			Endpoint_ClearSETUP();
			Endpoint_Write_8(g_idle_count);
			Endpoint_ClearIN();
			Endpoint_ClearStatusStage();
		}
		break;

	case HID_REQ_GetProtocol:
		if (USB_ControlRequest.bmRequestType == (REQDIR_DEVICETOHOST | REQTYPE_CLASS | REQREC_INTERFACE))
		{
			Endpoint_ClearSETUP();
			Endpoint_Write_8(g_protocol);
			Endpoint_ClearIN();
			Endpoint_ClearStatusStage();
		}
		break;

	case HID_REQ_SetProtocol:
		if (USB_ControlRequest.bmRequestType == (REQDIR_HOSTTODEVICE | REQTYPE_CLASS | REQREC_INTERFACE))
		{
			Endpoint_ClearSETUP();
			Endpoint_ClearStatusStage();
			g_protocol = (uint8_t)(USB_ControlRequest.wValue & 0xFF);
		}
		break;
	}
}
