/*
 * ROTORR - USB-Deskriptoren (LUFA 130901)
 * Ein HID-Interface mit vier Maus-Collections (Report-ID 1-4). Windows legt fuer jede
 * Top-Level-Collection ein eigenes HID-Geraet an, MAME sieht also vier getrennte Maeuse.
 * Report-ID 5: herstellerspezifische Collection fuer den Bootloader-Befehl des Tools.
 * GPL-2.0, Designed by Frischbrot in 2026
 */
#ifndef ROTORR_DESCRIPTORS_H__INCLUDED
#define ROTORR_DESCRIPTORS_H__INCLUDED

#include <avr/pgmspace.h>
#include <LUFA/Drivers/USB/USB.h>
#include "devconfig.h"

typedef struct
{
	USB_Descriptor_Configuration_Header_t  Config;
	USB_Descriptor_Interface_t             HID_Interface;
	USB_HID_Descriptor_HID_t               HID_MouseHID;
	USB_Descriptor_Endpoint_t              HID_ReportINEndpoint;
} USB_Descriptor_Configuration_t;

#define MOUSE_EPADDR          (ENDPOINT_DIR_IN | 1)
#define MOUSE_EPSIZE          8
#define MOUSE_INTERVAL_MS     1
#define MOUSE_REPORT_SIZE     4      /* Report-ID, Knoepfe (immer 0), X, Y */
#define NUM_MICE              4
#define BOOT_REPORT_ID        5      /* herstellerspezifische Collection fuer den Bootloader-Befehl */

/* CALLBACK_USB_GetDescriptor() ist in LUFA/Drivers/USB/Core/Device.h deklariert */

#endif
