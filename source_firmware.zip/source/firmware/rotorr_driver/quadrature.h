/*
 * ROTORR - Quadratur-Decoder (fuer Firmware und Host-Test gemeinsam)
 * GPL-2.0, Designed by Frischbrot in 2026
 *
 * Jede Achse hat zwei Encoder-Kanaele A und B. Bei jeder Abtastung wird der alte Zustand (2 Bit)
 * mit dem neuen (2 Bit) zu einem Index 0..15 verbunden. Die Tabelle liefert +1, -1 oder 0
 * (0 = keine Aenderung oder ungueltiger Sprung ueber zwei Zustaende).
 * Folge vorwaerts: 00 -> 01 -> 11 -> 10 -> 00 (B fuehrt A nach), jede Flanke zaehlt (4-fach-Aufloesung).
 */
#ifndef QUADRATURE_H__INCLUDED
#define QUADRATURE_H__INCLUDED

#include <stdint.h>

static const int8_t QDEC_TABLE[16] = {
	 0, +1, -1,  0,
	-1,  0,  0, +1,
	+1,  0,  0, -1,
	 0, -1, +1,  0
};

/* Zustand aus zwei Port-Bits bilden: Bit 1 = Kanal A, Bit 0 = Kanal B
   (als Bit-Test geschrieben, damit avr-gcc daraus wenige SBRC/ORI-Befehle macht statt Schiebe-Schleifen) */
#define QDEC_STATE(port, bitA, bitB) ((uint8_t)((((port) & (1u << (bitA))) ? 2u : 0u) | (((port) & (1u << (bitB))) ? 1u : 0u)))

/* eine Achse abtasten: prev = alter Zustand (wird aktualisiert), cnt = Zaehler */
#define QDEC_STEP(prev, cnt, s) do { uint8_t const _s = (s); (cnt) += QDEC_TABLE[((prev) << 2) | _s]; (prev) = _s; } while (0)

#endif
