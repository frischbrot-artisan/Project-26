/*
 * ROTORR Rev 0.4b - Konfiguration
 * 2 Trackbaelle + 2 Spinner am Pro Micro (ATmega32U4), meldet sich als 4 USB-Maeuse (keine Knoepfe).
 * Die Knoepfe laufen ueber das VPINBALL- oder ARCADE-Board (Tastatur).
 *
 * Pinbelegung (Klemme -> Pro-Micro-Pin -> Port):
 *   TRACKBALL 1  XA = D15 (PB1)  XB = D14 (PB3)  YA = D16 (PB2)  YB = D10 (PB6)   -> Maus 1, X/Y
 *   SPINNER 1    A  = D9  (PB5)  B  = D8  (PB4)                                   -> Maus 3, X
 *   TRACKBALL 2  XA = TX  (PD3)  XB = RX  (PD2)  YA = D2  (PD1)  YB = D3  (PD0)   -> Maus 2, X/Y
 *   SPINNER 2    A  = D4  (PD4)  B  = D6  (PD7)                                   -> Maus 4, X
 * Laeuft eine Achse falsch herum: A und B an der Klemme tauschen, oder die Achse in MAME umkehren,
 * oder hier ROTORR_INVERT setzen (Bit 0 = Maus1 X, 1 = Maus1 Y, 2 = Maus2 X, 3 = Maus2 Y, 4 = Maus3, 5 = Maus4).
 */
#ifndef DEVCONFIG_H__INCLUDED
#define DEVCONFIG_H__INCLUDED

#define USB_PRODUCT_STRING  "ROTORR Rev 0.4b"
#define USB_VENDOR_ID       0xFAFA      /* PID ausserhalb der LED-Wiz-IDs 0x00F0-0x00FF: DOF/LEDBlinky ignorieren das Board */
#define USB_PRODUCT_ID      0x0100

#if !defined(ROTORR_INVERT)
#define ROTORR_INVERT     0x00
#endif

/* Abtastrate der Encoder: 16 MHz / 8 / (OCR0A + 1) = 50 kHz
   -> sicher erfasst werden ca. 25 000 Flanken/s je Achse (z. B. Spinner mit 600 Impulsen/U: ca. 10 U/s) */
#define ROTORR_OCR0A      39
#define ROTORR_TICKS_PER_MS 50

#endif
