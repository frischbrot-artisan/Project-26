/*
 * ROTORR Rev 0.4b - 2 Trackbaelle + 2 Spinner als 4 USB-Maeuse
 * Pro Micro (ATmega32U4, 16 MHz), LUFA 130901 (Dean Camera, www.lufa-lib.org)
 * GPL-2.0, Designed by Frischbrot in 2026
 *
 * Ablauf:
 *  - Timer0 tastet alle 12 Encoder-Signale 50 000-mal pro Sekunde ab (Port B und Port D auf einmal)
 *    und zaehlt jede Flanke (Quadratur, 4-fach-Aufloesung). Hat sich an einem Port nichts geaendert,
 *    wird dessen Auswertung uebersprungen (kurzer Interrupt in Ruhe).
 *  - Die Hauptschleife holt die Zaehler bei jedem Durchlauf ab (8-Bit-Zaehler im Interrupt = schnell).
 *  - Die Hauptschleife schickt die gesammelten Bewegungen als relative Maus-Reports an den PC,
 *    reihum fuer die vier Maeuse (USB-Abfrage jede Millisekunde).
 *  - Die RX-LED des Pro Micro blinkt bei Bewegung (Test ohne PC-Programm).
 */
#include <stdint.h>
#include <avr/io.h>
#include <avr/wdt.h>
#include <avr/power.h>
#include <avr/interrupt.h>
#include <util/atomic.h>
#include <LUFA/Drivers/USB/USB.h>

#include "devconfig.h"
#include "quadrature.h"
#include "rotorr_descriptors.h"

/* Achsen: 0 = Maus1 X, 1 = Maus1 Y, 2 = Maus2 X, 3 = Maus2 Y, 4 = Maus3 X, 5 = Maus4 X */
#define NUM_AXES 6
static volatile int8_t g_count[NUM_AXES];   /* max. 1 Flanke pro Abtastung; wird bei jedem Schleifendurchlauf geleert */
static uint8_t g_lastb, g_lastd;            /* letzte Port-Werte (nur Encoder-Bits) */
static uint8_t g_prev[NUM_AXES];
static volatile uint16_t g_ticks;

static int16_t g_acc[NUM_AXES];     /* gesammelt, noch nicht gesendet (nur Hauptschleife) */
static uint8_t g_next_mouse;
static uint8_t g_idle_count;        /* HID SET_IDLE (wird gespeichert, aber nicht benoetigt) */

/* --- Pins: Eingaenge mit Pull-up (zusaetzlich 4,7 k auf der Platine) */
#define PB_MASK ((1 << 1) | (1 << 2) | (1 << 3) | (1 << 4) | (1 << 5) | (1 << 6))
#define PD_MASK ((1 << 0) | (1 << 1) | (1 << 2) | (1 << 3) | (1 << 4) | (1 << 7))

static void sample_init(uint8_t b, uint8_t d)
{
	g_prev[0] = QDEC_STATE(b, 1, 3);   /* TRACKBALL 1 X: A = PB1 (D15), B = PB3 (D14) */
	g_prev[1] = QDEC_STATE(b, 2, 6);   /* TRACKBALL 1 Y: A = PB2 (D16), B = PB6 (D10) */
	g_prev[2] = QDEC_STATE(d, 3, 2);   /* TRACKBALL 2 X: A = PD3 (TX),  B = PD2 (RX)  */
	g_prev[3] = QDEC_STATE(d, 1, 0);   /* TRACKBALL 2 Y: A = PD1 (D2),  B = PD0 (D3)  */
	g_prev[4] = QDEC_STATE(b, 5, 4);   /* SPINNER 1:     A = PB5 (D9),  B = PB4 (D8)  */
	g_prev[5] = QDEC_STATE(d, 4, 7);   /* SPINNER 2:     A = PD4 (D4),  B = PD7 (D6)  */
}

ISR(TIMER0_COMPA_vect)
{
	uint8_t const b = PINB & PB_MASK;
	uint8_t const d = PIND & PD_MASK;
	if (b != g_lastb)
	{
		g_lastb = b;
		QDEC_STEP(g_prev[0], g_count[0], QDEC_STATE(b, 1, 3));
		QDEC_STEP(g_prev[1], g_count[1], QDEC_STATE(b, 2, 6));
		QDEC_STEP(g_prev[4], g_count[4], QDEC_STATE(b, 5, 4));
	}
	if (d != g_lastd)
	{
		g_lastd = d;
		QDEC_STEP(g_prev[2], g_count[2], QDEC_STATE(d, 3, 2));
		QDEC_STEP(g_prev[3], g_count[3], QDEC_STATE(d, 1, 0));
		QDEC_STEP(g_prev[5], g_count[5], QDEC_STATE(d, 4, 7));
	}
	g_ticks++;
}

static void hardware_init(void)
{
	MCUSR &= ~(1 << WDRF);
	wdt_disable();
	clock_prescale_set(clock_div_1);

	DDRB &= ~PB_MASK; PORTB |= PB_MASK;
	DDRD &= ~PD_MASK; PORTD |= PD_MASK;
	DDRB |= (1 << 0); PORTB |= (1 << 0);     /* RX-LED (aktiv low): aus */
	DDRD |= (1 << 5); PORTD |= (1 << 5);     /* TX-LED (aktiv low): aus */

	g_lastb = PINB & PB_MASK;
	g_lastd = PIND & PD_MASK;
	sample_init(g_lastb, g_lastd);

	TCCR0A = (1 << WGM01);                   /* CTC */
	TCCR0B = (1 << CS01);                    /* Vorteiler 8 -> 2 MHz */
	OCR0A  = ROTORR_OCR0A;                 /* -> 50 kHz */
	TIMSK0 = (1 << OCIE0A);

	USB_Init();
}

static int8_t take(int16_t * const acc)
{
	int16_t v = *acc;
	if (v > 127) v = 127;
	if (v < -127) v = -127;
	*acc -= v;
	return (int8_t)v;
}

static void collect(void)
{
	ATOMIC_BLOCK(ATOMIC_RESTORESTATE)
	{
		for (uint8_t i = 0; i < NUM_AXES; i++)
		{
			int16_t c = g_count[i];               /* int8 -> int16 */
			g_count[i] = 0;
			if (ROTORR_INVERT & (1 << i)) c = -c;
			int16_t const v = g_acc[i] + c;
			g_acc[i] = (v > 30000) ? 30000 : ((v < -30000) ? -30000 : v);   /* PC fragt nicht ab: nicht ueberlaufen */
		}
	}
}

static uint16_t ticks_now(void)
{
	uint16_t t;
	ATOMIC_BLOCK(ATOMIC_RESTORESTATE) { t = g_ticks; }
	return t;
}

static void mouse_task(void)
{
	static uint16_t led_until = 0;
	static uint8_t led_on = 0;

	if (led_on && (int16_t)(ticks_now() - led_until) >= 0) { PORTB |= (1 << 0); led_on = 0; }

	if (USB_DeviceState != DEVICE_STATE_Configured)
	{
		/* ohne PC nichts aufsammeln, sonst springt der Zeiger beim Verbinden */
		ATOMIC_BLOCK(ATOMIC_RESTORESTATE) { for (uint8_t i = 0; i < NUM_AXES; i++) g_count[i] = 0; }
		for (uint8_t i = 0; i < NUM_AXES; i++) g_acc[i] = 0;
		return;
	}

	collect();                                              /* bei jedem Durchlauf: 8-Bit-Zaehler laufen nicht ueber */

	Endpoint_SelectEndpoint(MOUSE_EPADDR);
	if (!Endpoint_IsINReady())
		return;

	/* reihum die naechste Maus mit Bewegung senden */
	static const uint8_t AX_X[NUM_MICE] = {0, 2, 4, 5};
	static const uint8_t AX_Y[NUM_MICE] = {1, 3, 0xFF, 0xFF};
	for (uint8_t n = 0; n < NUM_MICE; n++)
	{
		uint8_t const m = (uint8_t)((g_next_mouse + n) % NUM_MICE);
		uint8_t const ax = AX_X[m], ay = AX_Y[m];
		if (g_acc[ax] == 0 && (ay == 0xFF || g_acc[ay] == 0))
			continue;

		uint8_t report[MOUSE_REPORT_SIZE];
		report[0] = (uint8_t)(m + 1);                       /* Report-ID 1-4 */
		report[1] = 0;                                      /* keine Knoepfe */
		report[2] = (uint8_t)take(&g_acc[ax]);
		report[3] = (ay == 0xFF) ? 0 : (uint8_t)take(&g_acc[ay]);

		Endpoint_Write_Stream_LE(report, sizeof(report), NULL);
		Endpoint_ClearIN();

		g_next_mouse = (uint8_t)((m + 1) % NUM_MICE);
		PORTB &= ~(1 << 0); led_on = 1;                     /* RX-LED an */
		led_until = (uint16_t)(ticks_now() + 30 * ROTORR_TICKS_PER_MS);
		break;
	}
}

int main(void)
{
	hardware_init();
	GlobalInterruptEnable();

	for (;;)
	{
		mouse_task();
		USB_USBTask();
	}
}

/* ------------------------------------------------------------------ USB-Ereignisse */

void EVENT_USB_Device_ConfigurationChanged(void)
{
	Endpoint_ConfigureEndpoint(MOUSE_EPADDR, EP_TYPE_INTERRUPT, MOUSE_EPSIZE, 1);
}

void EVENT_USB_Device_ControlRequest(void)
{
	switch (USB_ControlRequest.bRequest)
	{
	case HID_REQ_GetReport:
		if (USB_ControlRequest.bmRequestType == (REQDIR_DEVICETOHOST | REQTYPE_CLASS | REQREC_INTERFACE))
		{
			uint8_t report[MOUSE_REPORT_SIZE] = {0, 0, 0, 0};
			uint8_t const id = (uint8_t)(USB_ControlRequest.wValue & 0xFF);
			report[0] = (id >= 1 && id <= NUM_MICE) ? id : 1;

			Endpoint_ClearSETUP();
			Endpoint_Write_Control_Stream_LE(report, sizeof(report));
			Endpoint_ClearOUT();
		}
		break;

	case HID_REQ_SetIdle:
		if (USB_ControlRequest.bmRequestType == (REQDIR_HOSTTODEVICE | REQTYPE_CLASS | REQREC_INTERFACE))
		{
			Endpoint_ClearSETUP();
			Endpoint_ClearStatusStage();
			g_idle_count = (uint8_t)((USB_ControlRequest.wValue & 0xFF00) >> 8);
		}
		break;

	case HID_REQ_GetIdle:
		if (USB_ControlRequest.bmRequestType == (REQDIR_DEVICETOHOST | REQTYPE_CLASS | REQREC_INTERFACE))
		{
			Endpoint_ClearSETUP();
			Endpoint_Write_8(g_idle_count);
			Endpoint_ClearIN();
			Endpoint_ClearStatusStage();
		}
		break;

	case HID_REQ_SetProtocol:
		if (USB_ControlRequest.bmRequestType == (REQDIR_HOSTTODEVICE | REQTYPE_CLASS | REQREC_INTERFACE))
		{
			Endpoint_ClearSETUP();
			Endpoint_ClearStatusStage();
		}
		break;
	}
}
