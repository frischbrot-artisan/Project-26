/*
 * ROTORR - USB-Deskriptoren (LUFA 130901)
 * Aufbau nach dem Muster von descriptors.c (LWCloneU2, Andreas Dittrich) und den LUFA-Demos (Dean Camera).
 * GPL-2.0, Designed by Frischbrot in 2026
 */
#include "rotorr_descriptors.h"

#define XYZ_TO_BCD(a,b,c) \
	((uint16_t)(((a)/10) % 10) << 12) | \
	((uint16_t)((a) % 10) << 8) | \
	((uint16_t)((b) % 10) << 4) | \
	((uint16_t)((c) % 10) << 0)

#define USB_WIDEN2(x) L##x
#define USB_WIDEN(x) USB_WIDEN2(x)

#define USB_STRING_TABLE(_map_) \
	_map_(ManufacturerString_id,  "Frischbrot") \
	_map_(ProductString_id,       USB_PRODUCT_STRING)

typedef enum {
	LanguageString_id = 0,
	#define MAP(x, y) x,
	USB_STRING_TABLE(MAP)
	#undef MAP
} UsbStringsEnum;

static const USB_Descriptor_String_t PROGMEM LanguageString =
{
	.Header                 = {.Size = USB_STRING_LEN(1), .Type = DTYPE_String},
	.UnicodeString          = {LANGUAGE_ID_ENG}
};

#define MAP(name, str) \
static const USB_Descriptor_String_t PROGMEM name##__str_ = \
{ \
	.Header                 = {.Size = USB_STRING_LEN(sizeof(str) - 1), .Type = DTYPE_String}, \
	.UnicodeString          = USB_WIDEN(str) \
};
USB_STRING_TABLE(MAP)
#undef MAP

/* eine relative Maus: 3 Knoepfe (immer 0, damit Windows sie sicher als Maus erkennt), X und Y je -127..127 */
#define MOUSE_COLLECTION(id) \
	0x05, 0x01,        /* USAGE_PAGE (Generic Desktop) */ \
	0x09, 0x02,        /* USAGE (Mouse) */ \
	0xa1, 0x01,        /* COLLECTION (Application) */ \
	0x85, (id),        /*   REPORT_ID */ \
	0x09, 0x01,        /*   USAGE (Pointer) */ \
	0xa1, 0x00,        /*   COLLECTION (Physical) */ \
	0x05, 0x09,        /*     USAGE_PAGE (Button) */ \
	0x19, 0x01,        /*     USAGE_MINIMUM (Button 1) */ \
	0x29, 0x03,        /*     USAGE_MAXIMUM (Button 3) */ \
	0x15, 0x00,        /*     LOGICAL_MINIMUM (0) */ \
	0x25, 0x01,        /*     LOGICAL_MAXIMUM (1) */ \
	0x95, 0x03,        /*     REPORT_COUNT (3) */ \
	0x75, 0x01,        /*     REPORT_SIZE (1) */ \
	0x81, 0x02,        /*     INPUT (Data,Var,Abs) */ \
	0x95, 0x01,        /*     REPORT_COUNT (1) */ \
	0x75, 0x05,        /*     REPORT_SIZE (5) */ \
	0x81, 0x03,        /*     INPUT (Cnst,Var,Abs) */ \
	0x05, 0x01,        /*     USAGE_PAGE (Generic Desktop) */ \
	0x09, 0x30,        /*     USAGE (X) */ \
	0x09, 0x31,        /*     USAGE (Y) */ \
	0x15, 0x81,        /*     LOGICAL_MINIMUM (-127) */ \
	0x25, 0x7f,        /*     LOGICAL_MAXIMUM (127) */ \
	0x75, 0x08,        /*     REPORT_SIZE (8) */ \
	0x95, 0x02,        /*     REPORT_COUNT (2) */ \
	0x81, 0x06,        /*     INPUT (Data,Var,Rel) */ \
	0xc0,              /*   END_COLLECTION */ \
	0xc0               /* END_COLLECTION */

static const USB_Descriptor_HIDReport_Datatype_t PROGMEM MouseReport[] =
{
	MOUSE_COLLECTION(1),   /* Maus 1: TRACKBALL 1 */
	MOUSE_COLLECTION(2),   /* Maus 2: TRACKBALL 2 */
	MOUSE_COLLECTION(3),   /* Maus 3: SPINNER 1 (X) */
	MOUSE_COLLECTION(4)    /* Maus 4: SPINNER 2 (X) */
};

static const USB_Descriptor_Device_t PROGMEM DeviceDescriptor =
{
	.Header                 = {.Size = sizeof(USB_Descriptor_Device_t), .Type = DTYPE_Device},
	.USBSpecification       = XYZ_TO_BCD(1,1,0),
	.Class                  = USB_CSCP_NoDeviceClass,
	.SubClass               = USB_CSCP_NoDeviceSubclass,
	.Protocol               = USB_CSCP_NoDeviceProtocol,
	.Endpoint0Size          = FIXED_CONTROL_ENDPOINT_SIZE,
	.VendorID               = USB_VENDOR_ID,
	.ProductID              = USB_PRODUCT_ID,
	.ReleaseNumber          = XYZ_TO_BCD(0,4,0),
	.ManufacturerStrIndex   = ManufacturerString_id,
	.ProductStrIndex        = ProductString_id,
	.SerialNumStrIndex      = NO_DESCRIPTOR,
	.NumberOfConfigurations = FIXED_NUM_CONFIGURATIONS
};

#define IFACENUMBER_MOUSE 0

static const USB_Descriptor_Configuration_t PROGMEM ConfigurationDescriptor =
{
	.Config =
	{
		.Header                 = {.Size = sizeof(USB_Descriptor_Configuration_Header_t), .Type = DTYPE_Configuration},
		.TotalConfigurationSize = sizeof(USB_Descriptor_Configuration_t),
		.TotalInterfaces        = 1,
		.ConfigurationNumber    = 1,
		.ConfigurationStrIndex  = NO_DESCRIPTOR,
		.ConfigAttributes       = USB_CONFIG_ATTR_RESERVED,
		.MaxPowerConsumption    = USB_CONFIG_POWER_MA(200)
	},

	.HID_Interface =
	{
		.Header                 = {.Size = sizeof(USB_Descriptor_Interface_t), .Type = DTYPE_Interface},
		.InterfaceNumber        = IFACENUMBER_MOUSE,
		.AlternateSetting       = 0x00,
		.TotalEndpoints         = 1,
		.Class                  = HID_CSCP_HIDClass,
		.SubClass               = HID_CSCP_NonBootSubclass,
		.Protocol               = HID_CSCP_NonBootProtocol,
		.InterfaceStrIndex      = NO_DESCRIPTOR
	},

	.HID_MouseHID =
	{
		.Header                 = {.Size = sizeof(USB_HID_Descriptor_HID_t), .Type = HID_DTYPE_HID},
		.HIDSpec                = XYZ_TO_BCD(1,1,1),
		.CountryCode            = 0x00,
		.TotalReportDescriptors = 1,
		.HIDReportType          = HID_DTYPE_Report,
		.HIDReportLength        = sizeof(MouseReport)
	},

	.HID_ReportINEndpoint =
	{
		.Header                 = {.Size = sizeof(USB_Descriptor_Endpoint_t), .Type = DTYPE_Endpoint},
		.EndpointAddress        = MOUSE_EPADDR,
		.Attributes             = (EP_TYPE_INTERRUPT | ENDPOINT_ATTR_NO_SYNC | ENDPOINT_USAGE_DATA),
		.EndpointSize           = MOUSE_EPSIZE,
		.PollingIntervalMS      = MOUSE_INTERVAL_MS
	}
};

uint16_t CALLBACK_USB_GetDescriptor(
	const uint16_t wValue,
	const uint8_t wIndex,
	const void** const DescriptorAddress,
	uint8_t *const DescriptorMemorySpace)
{
	const uint8_t  DescriptorType   = (wValue >> 8);
	const uint8_t  DescriptorNumber = (wValue & 0xFF);

	uint8_t memspace;
	uint8_t * const pmemspace = (DescriptorMemorySpace != NULL) ? DescriptorMemorySpace : &memspace;

	*pmemspace = MEMSPACE_FLASH;

	const void* Address = NULL;
	uint16_t    Size    = NO_DESCRIPTOR;

	switch (DescriptorType)
	{
		case DTYPE_Device:
			Address = &DeviceDescriptor;
			Size    = sizeof(USB_Descriptor_Device_t);
			break;

		case DTYPE_Configuration:
			Address = &ConfigurationDescriptor;
			Size    = sizeof(USB_Descriptor_Configuration_t);
			break;

		case DTYPE_String:
			switch (DescriptorNumber)
			{
				case LanguageString_id:
					Address = &LanguageString;
					Size    = pgm_read_byte(&LanguageString.Header.Size);
					break;

				#define MAP(name, str) \
				case name: \
					Address = &name##__str_; \
					Size    = pgm_read_byte(&name##__str_.Header.Size); \
					break;
				USB_STRING_TABLE(MAP)
				#undef MAP
			}
			break;

		case HID_DTYPE_HID:
			if (wIndex == IFACENUMBER_MOUSE)
			{
				Address = &ConfigurationDescriptor.HID_MouseHID;
				Size    = sizeof(USB_HID_Descriptor_HID_t);
			}
			break;

		case HID_DTYPE_Report:
			if (wIndex == IFACENUMBER_MOUSE)
			{
				Address = &MouseReport;
				Size    = sizeof(MouseReport);
			}
			break;
	}

	*DescriptorAddress = Address;

	return Size;
}
