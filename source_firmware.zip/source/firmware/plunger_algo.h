/*
 * LWCloneU2 Resurrected - analog plunger (VPINBALL Rev 0.9c, potentiometer on A15)
 *
 * Portable C (no AVR headers), called every PLG_TICK_MS from panel.c, also used by the
 * PC test simulation. Raw values are "counts16" = 10-bit ADC average << 4 (0..16368).
 *
 * Wiring: potentiometer end 1 -> PLG + (3.3 V through R66 1.5k), wiper -> PLG S (A15),
 * end 2 -> GND. With a 10k potentiometer the wiper reaches about 2.87 V = AREF (full scale).
 *
 * Output (gamepad Z axis): 0 = rest position, +32767 = fully pulled back,
 * negative values = pushed forward beyond the rest position (down to -8192).
 * Without a calibration the output is always 0 (an open input would only report noise).
 *
 * Calibration: leave the plunger at rest, start the calibration, then pull it all the way
 * back and release it two or three times within the calibration time. The rest position is
 * taken at the start, the full-pull position is the farthest value seen.
 *
 * Firing: Visual Pinball calculates the launch speed from consecutive positions. When a fast
 * forward movement is detected, the output jumps straight to the rest position and stays there
 * for PLG_FIRE_TICKS (the plunger spring bounces), so VPX sees one big, fast step.
 */

#ifndef PLUNGER_ALGO_H__INCLUDED
#define PLUNGER_ALGO_H__INCLUDED

#include <stdint.h>

#define PLG_TICK_MS       2
#define PLG_RAW_MAX       16368
#define PLG_MIN_SPAN      1600      /* calibration needs at least ~10 % of the ADC range */
#define PLG_DEADBAND      400       /* +/-1.2 % around rest -> 0 (no jitter at rest) */
#define PLG_FWD_LIMIT     (-8192)
#define PLG_FIRE_MIN      6554      /* firing only from >= 20 % pulled */
#define PLG_FIRE_DROP     4000      /* forward movement of >= 12 % within 2 ticks (4 ms) */
#define PLG_FIRE_TICKS    25        /* 50 ms rest position after firing */
#define PLG_HIST          8         /* 16 ms position history */

#define PLG_ST_ACTIVE     0x10      /* status bits, combined with the nudge status in the report */
#define PLG_ST_CAL        0x20
#define PLG_ST_FIRE       0x40

typedef struct {
	uint16_t rest;     /* counts16 */
	uint16_t max;      /* counts16, full pull (may be below rest: reversed potentiometer) */
	uint8_t valid;
} plunger_cfg_t;

typedef struct {
	int32_t filt;      /* counts16 << 2 */
	uint8_t have;
	int16_t hist[PLG_HIST];
	uint8_t hidx;
	uint8_t fire_t;
	uint16_t cal_t;
	uint16_t cal_rest;
	uint16_t cal_far;
	int16_t out;
	uint8_t status;
} plunger_state_t;

static inline void plunger_init(plunger_state_t *s)
{
	uint8_t i;
	s->filt = 0; s->have = 0; s->hidx = 0; s->fire_t = 0;
	s->cal_t = 0; s->cal_rest = 0; s->cal_far = 0; s->out = 0; s->status = 0;
	for (i = 0; i < PLG_HIST; i++) s->hist[i] = 0;
}

static inline uint8_t plunger_cfg_ok(const plunger_cfg_t *c)
{
	int32_t span = (int32_t)c->max - (int32_t)c->rest;
	if (span < 0) span = -span;
	return c->valid && c->rest <= PLG_RAW_MAX && c->max <= PLG_RAW_MAX && span >= PLG_MIN_SPAN;
}

/* start a calibration of 'seconds' (2..30) */
static inline void plunger_cal_start(plunger_state_t *s, uint8_t seconds)
{
	if (seconds < 2) seconds = 2;
	if (seconds > 30) seconds = 30;
	s->cal_rest = (uint16_t)(s->filt >> 2);
	s->cal_far = s->cal_rest;
	s->cal_t = (uint16_t)seconds * (1000 / PLG_TICK_MS);
}

/* returns 1 when a calibration has just finished successfully (cfg updated -> store it) */
static inline uint8_t plunger_tick(plunger_state_t *s, plunger_cfg_t *c, uint16_t raw)
{
	uint8_t saved = 0;
	int32_t v, pos, span, d;
	uint8_t i;

	if (!s->have) { s->filt = (int32_t)raw << 2; s->have = 1; }
	s->filt += (((int32_t)raw << 2) - s->filt) >> 1;
	v = s->filt >> 2;

	if (s->cal_t > 0)
	{
		int32_t df = (int32_t)s->cal_far - (int32_t)s->cal_rest;
		int32_t dv = v - (int32_t)s->cal_rest;
		if ((dv < 0 ? -dv : dv) > (df < 0 ? -df : df)) s->cal_far = (uint16_t)v;

		if (--s->cal_t == 0)
		{
			plunger_cfg_t n;
			n.rest = s->cal_rest; n.max = s->cal_far; n.valid = 1;
			if (plunger_cfg_ok(&n)) { *c = n; saved = 1; }
			s->fire_t = 0;
			for (i = 0; i < PLG_HIST; i++) s->hist[i] = 0;
		}
		s->out = 0;
		s->status = PLG_ST_CAL | (plunger_cfg_ok(c) ? PLG_ST_ACTIVE : 0);
		return saved;
	}

	if (!plunger_cfg_ok(c))
	{
		s->out = 0;
		s->status = 0;
		return 0;
	}

	span = (int32_t)c->max - (int32_t)c->rest;
	pos = ((v - (int32_t)c->rest) * 32767L) / span;
	if (pos > 32767) pos = 32767;
	if (pos < PLG_FWD_LIMIT) pos = PLG_FWD_LIMIT;
	if (pos > -PLG_DEADBAND && pos < PLG_DEADBAND) pos = 0;

	/* firing detection: peak of the last 16 ms and drop within the last 2 ticks */
	{
		int16_t peak = 0;
		int16_t prev2 = s->hist[(uint8_t)(s->hidx + PLG_HIST - 2) % PLG_HIST];
		int16_t prev1 = s->hist[(uint8_t)(s->hidx + PLG_HIST - 1) % PLG_HIST];
		for (i = 0; i < PLG_HIST; i++) if (s->hist[i] > peak) peak = s->hist[i];
		d = (int32_t)prev2 - pos;

		if (s->fire_t > 0)
		{
			s->fire_t--;
			if (pos >= PLG_FIRE_MIN && pos > prev1 + 200) s->fire_t = 0;   /* pulled back again: normal */
		}
		else if (peak >= PLG_FIRE_MIN && d >= PLG_FIRE_DROP)
		{
			s->fire_t = PLG_FIRE_TICKS;
		}
	}

	s->hist[s->hidx] = (int16_t)pos;
	s->hidx = (uint8_t)((s->hidx + 1) % PLG_HIST);

	s->out = (s->fire_t > 0) ? 0 : (int16_t)pos;
	s->status = PLG_ST_ACTIVE | ((s->fire_t > 0) ? PLG_ST_FIRE : 0);
	return 0;
}

#endif /* PLUNGER_ALGO_H__INCLUDED */
