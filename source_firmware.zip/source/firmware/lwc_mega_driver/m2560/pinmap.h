/*
 * LWCloneU2
 * Copyright (C) 2013 Andreas Dittrich <lwcloneu2@cithraidt.de>
 *
 * This program is free software; you can redistribute it and/or modify it under the terms of the
 * GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program;
 * if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

/*
 * Pin map for the "LWCloneU2 Resurrected VPINBALL" shield Rev 0.9c (Arduino Mega 2560 R3).
 * The order of LED_MAPPING_TABLE defines the LED-Wiz / DOF output numbers 1..32,
 * exactly as printed on the shield.
 *
 *   1-16  MOSFET outputs (6 A),     XIO header even pins D52..D22, terminals J8-J15 (top edge)
 *  17-32  ULN2803 outputs (0.5 A),  XIO header odd pins  D23..D53, terminals J16-J23 (right edge)
 *
 * Inputs (PANEL_MAPPING_TABLE) and SHIFT_SWITCH_INDEX are unchanged from the stock
 * arduino_mega2560 firmware except A15: 31 buttons on D2-D17, D20, D21, A0, A1, A4-A14 (switch
 * to GND, internal pull-ups). D15 is the shift button.
 * Rev 0.9c: A15 is the analog plunger (potentiometer, terminals GND / PLG S / PLG +),
 * reported as Z axis of the AccelGyro gamepad, see plunger_algo.h.
 * Accelerometer ADXL335: X -> A2, Y -> A3, reported as separate gamepad "AccelGyro" X/Y
 * (analog nudging), so it does not interfere with the joystick-2 directions on A7-A10.
 */

#define LED_MAPPING_TABLE(_map_) \
	\
	_map_( B, 1, 0 ) /*  1  D52  MOSFET */ \
	_map_( B, 3, 0 ) /*  2  D50  MOSFET */ \
	_map_( L, 1, 0 ) /*  3  D48  MOSFET */ \
	_map_( L, 3, 0 ) /*  4  D46  MOSFET */ \
	_map_( L, 5, 0 ) /*  5  D44  MOSFET */ \
	_map_( L, 7, 0 ) /*  6  D42  MOSFET */ \
	_map_( G, 1, 0 ) /*  7  D40  MOSFET */ \
	_map_( D, 7, 0 ) /*  8  D38  MOSFET */ \
	_map_( C, 1, 0 ) /*  9  D36  MOSFET */ \
	_map_( C, 3, 0 ) /* 10  D34  MOSFET */ \
	_map_( C, 5, 0 ) /* 11  D32  MOSFET */ \
	_map_( C, 7, 0 ) /* 12  D30  MOSFET */ \
	_map_( A, 6, 0 ) /* 13  D28  MOSFET */ \
	_map_( A, 4, 0 ) /* 14  D26  MOSFET */ \
	_map_( A, 2, 0 ) /* 15  D24  MOSFET */ \
	_map_( A, 0, 0 ) /* 16  D22  MOSFET */ \
	_map_( A, 1, 0 ) /* 17  D23  ULN2803 */ \
	_map_( A, 3, 0 ) /* 18  D25  ULN2803 */ \
	_map_( A, 5, 0 ) /* 19  D27  ULN2803 */ \
	_map_( A, 7, 0 ) /* 20  D29  ULN2803 */ \
	_map_( C, 6, 0 ) /* 21  D31  ULN2803 */ \
	_map_( C, 4, 0 ) /* 22  D33  ULN2803 */ \
	_map_( C, 2, 0 ) /* 23  D35  ULN2803 */ \
	_map_( C, 0, 0 ) /* 24  D37  ULN2803 */ \
	_map_( G, 2, 0 ) /* 25  D39  ULN2803 */ \
	_map_( G, 0, 0 ) /* 26  D41  ULN2803 */ \
	_map_( L, 6, 0 ) /* 27  D43  ULN2803 */ \
	_map_( L, 4, 0 ) /* 28  D45  ULN2803 */ \
	_map_( L, 2, 0 ) /* 29  D47  ULN2803 */ \
	_map_( L, 0, 0 ) /* 30  D49  ULN2803 */ \
	_map_( B, 2, 0 ) /* 31  D51  ULN2803 */ \
	_map_( B, 0, 0 ) /* 32  D53  ULN2803 */ \
	\
	/* end */

#if (USE_MOUSE)
#define MOUSE_X_CLK_INDEX    9
#define MOUSE_X_DIR_INDEX   10
#define MOUSE_Y_CLK_INDEX   11
#define MOUSE_Y_DIR_INDEX   12
#endif

#define SHIFT_SWITCH_INDEX   13

#define PANEL_MAPPING_TABLE(_map_) \
	\
	_map_( E, 4,    MOD_LeftShift,   0                 ) /* ( OC3B/INT4 )         Digital pin 2 (PWM) */ \
	_map_( E, 5,    MOD_RightShift,  0                 ) /* ( OC3C/INT5 )         Digital pin 3 (PWM) */ \
	_map_( G, 5,    MOD_LeftControl, 0                 ) /* ( OC0B )              Digital pin 4 (PWM) */ \
	_map_( E, 3,    MOD_RightControl,0                 ) /* ( OC3A/AIN1 )         Digital pin 5 (PWM) */ \
	_map_( H, 3,    KEY_Esc,         0                 ) /* ( OC4A )              Digital pin 6 (PWM) */ \
	_map_( H, 4,    KEY_Enter,       0                 ) /* ( OC4B )              Digital pin 7 (PWM) */ \
	_map_( H, 5,    KEY_1,           KEY_P             ) /* ( OC4C )              Digital pin 8 (PWM) */ \
	_map_( H, 6,    KEY_5,           KEY_5             ) /* ( OC2B )              Digital pin 9 (PWM) */ \
	_map_( B, 4,    KEY_A,           KEY_A             ) /* ( OC2A/PCINT4 )       Digital pin 10 (PWM) */ \
	_map_( B, 5,    KEY_S,           KEY_S             ) /* ( OC1A/PCINT5 )       Digital pin 11 (PWM) */ \
	_map_( B, 6,    KEY_D,           KEY_D             ) /* ( OC1B/PCINT6 )       Digital pin 12 (PWM) */ \
	_map_( B, 7,    J1_Up,           KEY_UpArrow       ) /* ( OC0A/OC1C/PCINT7 )  Digital pin 13 (PWM) */ \
	_map_( J, 1,    J1_Left,         KEY_LeftArrow     ) /* ( TXD3/PCINT10 )      Digital pin 14 (TX3) */ \
	_map_( J, 0,    0,               0                 ) /* ( RXD3/PCINT9 )       Digital pin 15 (RX3) */ \
	_map_( H, 1,    J2_Button5,      0                 ) /* ( TXD2 )              Digital pin 16 (TX2) */ \
	_map_( H, 0,    J2_Button4,      0                 ) /* ( RXD2 )              Digital pin 17 (RX2) */ \
	_map_( D, 1,    J2_Button3,      KM_ALT_F4         ) /* ( SDA/INT1 )          Digital pin 20 (SDA) */ \
	_map_( D, 0,    J2_Button2,      KM_SHIFT_F7       ) /* ( SCL/INT0 )          Digital pin 21 (SCL) */ \
	_map_( F, 0,    J1_Right,        KEY_RightArrow    ) /* ( ADC0 )              Analog pin 0 */ \
	_map_( F, 1,    J1_Button1,      KEY_Enter         ) /* ( ADC1 )              Analog pin 1 */ \
	_map_( F, 4,    J1_Button4,      0                 ) /* ( ADC4/TMK )          Analog pin 4 */ \
	_map_( F, 5,    J1_Button5,      0                 ) /* ( ADC5/TMS )          Analog pin 5 */ \
	_map_( F, 6,    J2_Button1,      KEY_F7            ) /* ( ADC6 )              Analog pin 6 */ \
	_map_( F, 7,    J2_Right,        AC_VolumeUp       ) /* ( ADC7 )              Analog pin 7 */ \
	_map_( K, 0,    J2_Left,         AC_VolumeDown     ) /* ( ADC8/PCINT16 )      Analog pin 8 */ \
	_map_( K, 1,    J2_Up,           KEY_PageUp        ) /* ( ADC9/PCINT17 )      Analog pin 9 */ \
	_map_( K, 2,    J2_Down,         KEY_PageDown      ) /* ( ADC10/PCINT18 )     Analog pin 10 */ \
	_map_( K, 3,    J1_Down,         KEY_DownArrow     ) /* ( ADC11/PCINT19 )     Analog pin 11 */ \
	_map_( K, 4,    KEY_2,           AC_Mute           ) /* ( ADC12/PCINT20 )     Analog pin 12 */ \
	_map_( K, 5,    J1_Button8,      0                 ) /* ( ADC13/PCINT21 )     Analog pin 13 */ \
	_map_( K, 6,    J1_Button7,      0                 ) /* ( ADC14/PCINT22 )     Analog pin 14 */ \
	/* Rev 0.9c: A15 (PK7) is the analog plunger input, see ADC_MAPPING_TABLE */ \
	\
	/* end */


	// (port, pin, mux, value_min, value_max, joyid, axis
	// for mega2560, mux is 0x00..0x07 => (ADC0..ADC7) and 0x20..0x27 => (ADC8..ADC15)
	// ADXL335 (GY-61) on the shield, X -> A2, Y -> A3 (same pins as the stock firmware),
	// reported via the separate AccelGyro gamepad (USE_ACCELGYRO in devconfig.h)
	// 5 V ADC reference: 0 g = 1.65 V (0.33), approx. +/-2 g = 1.05..2.25 V (0.21..0.45)
#define ADC_MAPPING_TABLE(_map_) \
	\
	_map_( F, 2, 0x02, 0.210, 0.450, ID_AccelGyro, 0 ) /* Analog Pin 2 = ADXL335 X */ \
	_map_( F, 3, 0x03, 0.210, 0.450, ID_AccelGyro, 1 ) /* Analog Pin 3 = ADXL335 Y */ \
	_map_( K, 7, 0x27, 0.000, 1.000, ID_AccelGyro, 2 ) /* Analog Pin 15 = plunger potentiometer (Rev 0.9c), Z axis */ \
	\
	/* end */
