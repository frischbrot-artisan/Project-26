/*
 * LWCloneU2
 * Copyright (C) 2013 Andreas Dittrich <lwcloneu2@cithraidt.de>
 *
 * This program is free software; you can redistribute it and/or modify it under the terms of the
 * GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program;
 * if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef DEVCONFIG_H__INCLUDED
#define DEVCONFIG_H__INCLUDED


/****************************************
 USB device config
****************************************/

#define ENABLE_LED_DEVICE

#define ENABLE_PANEL_DEVICE
#define ENABLE_ANALOG_INPUT
#define NUM_JOYSTICKS 2
#define USE_MOUSE 0
#define USE_CONSUMER 1
#define USE_KEYBOARD 1

/* accelerometer as separate analog device (X/Y), so it does not collide with the
   digital joystick-2 directions on A7-A10 */
#define USE_ACCELGYRO 1

/* board identification, read by the LWCloneU2 Resurrected Tool */
#define USB_PRODUCT_STRING "LWCloneU2 Resurrected VPINBALL Rev 0.4b"

/* default LED-Wiz ID 1 (0x00F0 = ID 1 ... 0x00FF = ID 16), changeable with the LWCloneU2 Resurrected Tool */
#define USB_PRODUCT_ID 0x00F0

/* coil protection (maximum on-time), normally set with the LWCloneU2 Resurrected Tool and stored in EEPROM
   (of the ATmega2560). These defaults are only used as long as nothing was stored.
   Example: MOSFET outputs 1-16, 2 s:
   #define COILPROT_DEFAULT_MASK     0x0000FFFFUL
   #define COILPROT_DEFAULT_TIME10MS 200                                                          */



#endif

