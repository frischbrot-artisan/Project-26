/*
 * bootjump.h - Bootloader-Start ueber USB fuer die Standalone-Boards (ROTORR, VERSUS)
 * Gleicher Ablauf wie der Bootloader-Befehl der LED-Wiz-Boards (main_usb.c, LWCloneU2):
 *   Befehl empfangen -> USB trennen -> Watchdog-Reset -> Magic-Wert pruefen -> in den Caterina-Bootloader springen.
 * Damit muss der Reset-Taster beim Flashen mit dem Tool nicht gedrueckt werden.
 *
 * Weil Windows Maus- und Tastatur-Collections exklusiv belegt, kommt der Befehl ueber eine eigene
 * herstellerspezifische Collection (Usage Page 0xFF00) mit einem 8-Byte-Output-Report:
 *   Report-ID, 66, 0x42, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xBD
 * GPL-2.0-or-later, Designed by Frischbrot in 2026
 */
#ifndef BOOTJUMP_H__INCLUDED
#define BOOTJUMP_H__INCLUDED

#include <stdint.h>
#include <avr/io.h>
#include <avr/wdt.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <LUFA/Drivers/USB/USB.h>

#define BOOTJUMP_MAGIC        0x42B8217CUL
#define BOOTJUMP_START_ADDR   ((uint16_t)(FLASHEND + 1UL - 4096UL))   /* Caterina: 4 KByte am Ende des Flash */

/* Collection fuer den Report-Deskriptor (wird an die vorhandenen Collections angehaengt) */
#define BOOTJUMP_COLLECTION(id) \
	0x06, 0x00, 0xff,  /* USAGE_PAGE (Vendor Defined 0xFF00) */ \
	0x09, 0x01,        /* USAGE (Vendor Usage 1) */ \
	0xa1, 0x01,        /* COLLECTION (Application) */ \
	0x85, (id),        /*   REPORT_ID */ \
	0x09, 0x01,        /*   USAGE (Vendor Usage 1) */ \
	0x15, 0x00,        /*   LOGICAL_MINIMUM (0) */ \
	0x26, 0xff, 0x00,  /*   LOGICAL_MAXIMUM (255) */ \
	0x75, 0x08,        /*   REPORT_SIZE (8) */ \
	0x95, 0x08,        /*   REPORT_COUNT (8) */ \
	0x91, 0x02,        /*   OUTPUT (Data,Var,Abs) */ \
	0xc0               /* END_COLLECTION */

#if !defined(BOOTJUMP_DESCRIPTOR_ONLY)   /* Deskriptor-Dateien brauchen nur das Makro oben */

static uint32_t g_bootjump_state __attribute__ ((section (".noinit")));

/* ganz am Anfang von hardware_init() aufrufen (statt MCUSR/wdt_disable) */
static inline void bootjump_check(void)
{
	uint8_t const mcusr = MCUSR;
	MCUSR = 0;          /* Caterina sieht danach keinen Reset-Grund und bleibt im Bootloader */
	wdt_disable();
	if ((mcusr & (1 << WDRF)) && g_bootjump_state == BOOTJUMP_MAGIC)
	{
		g_bootjump_state = 0;
		void (*bootloader)(void) = (void (*)(void))(BOOTJUMP_START_ADDR >> 1);   /* Wortadresse */
		bootloader();
	}
	g_bootjump_state = 0;
}

static void bootjump_restart(void)
{
	USB_Disable();
	USB_Detach();
	cli();
	_delay_ms(250);                     /* Trennung beim PC ankommen lassen */
	g_bootjump_state = BOOTJUMP_MAGIC;
	wdt_enable(WDTO_15MS);
	for (;;) {;}
}

/* im HID_REQ_SetReport-Zweig aufrufen. Liest die Daten selbst und quittiert den Request.
   Gibt 1 zurueck, wenn der Request bearbeitet wurde (Report-ID passt). */
static uint8_t bootjump_setreport(uint8_t const report_id)
{
	if ((USB_ControlRequest.wValue & 0xFF) != report_id)
		return 0;

	uint8_t d[9] = {0};
	Endpoint_ClearSETUP();
	Endpoint_Read_Control_Stream_LE(d, (USB_ControlRequest.wLength < sizeof(d)) ? USB_ControlRequest.wLength : sizeof(d));
	Endpoint_ClearIN();

	if (d[0] == report_id && d[1] == 66 && d[2] == 0x42 &&
	    d[3] == 0xFF && d[4] == 0xFF && d[5] == 0xFF && d[6] == 0xFF && d[7] == 0xFF &&
	    d[8] == (uint8_t)~0x42)
	{
		bootjump_restart();
	}
	return 1;
}

#endif /* !BOOTJUMP_DESCRIPTOR_ONLY */

#endif
