/*
 * LWCloneU2
 * Copyright (C) 2013 Andreas Dittrich <lwcloneu2@cithraidt.de>
 *
 * This program is free software; you can redistribute it and/or modify it under the terms of the
 * GNU General Public License as published by the Free Software Foundation;
 * either version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program;
 * if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

 /* Name: hid_input.c
 * Project: V-USB Mame Panel
 * Author: Andreas Oberdorfer
 * Creation Date: 2009-09-19
 * Copyright 2009 - 2011 Andreas Oberdorfer
 * License: GNU GPL v2 (see License.txt) or proprietary (CommercialLicense.txt)
 */

#include <string.h>
#include <stdbool.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <util/atomic.h>

#include <hwconfig.h>
#include "panel.h"
#include "comm.h"
#include "keydefs.h"
#include "clock.h"
#include "led.h"

#if (USE_ACCELGYRO)
#include <avr/eeprom.h>
#include "nudge_algo.h"
#include "plunger_algo.h"
#endif


#if !defined(PANEL_TASK)
	void panel_init(void) {}
	uint8_t panel_get_report(uint8_t **ppdata) { return 0; }
#else


const int DEBOUNCE = 5;

// derive the number of inputs from the table, let the compiler check that no pin is used twice
enum { 
	#define MAP(port, pin, normal_id, shift_id) port##pin##_index,
	PANEL_MAPPING_TABLE(MAP)
	NUMBER_OF_INPUTS,
	#undef MAP
	#if defined(LED_MAPPING_TABLE)
	#define MAP(port, pin, inv) port##pin##_index,
	LED_MAPPING_TABLE(MAP)
	#undef MAP
	#endif
	#if defined(ADC_MAPPING_TABLE)
	#define MAP(port, pin, mux, minval, maxval, joyid, axis) port##pin##_index,
	ADC_MAPPING_TABLE(MAP)
	#undef MAP
	#endif
};

#if defined(ADC_MAPPING_TABLE)
enum {
	#define MAP(port, pin, mux, minval, maxval, joyid, axis) port##pin##_adcindex,
	ADC_MAPPING_TABLE(MAP)
	#undef MAP
	NUM_ADC_CHANNELS
};
#endif

static uint8_t ReportBuffer[8];
static uint8_t InputState[NUMBER_OF_INPUTS];
static uint8_t shift_key = 0;
static uint8_t shift_key_cleanup = 0;
static uint8_t need_key_update = 0;
static uint8_t need_consumer_update = 0;

#if defined(SHIFT_SWITCH_INDEX) && defined(SHIFT_SWITCH_TAP)
// shift button with its own key (ARCADE: P1 START): pressed alone and released -> short tap of its normal key
#define SHIFT_TAP_MS 60
static uint8_t shift_used = 0;         // another input was pressed while the shift button was held
static uint8_t shift_tap = 0;          // 0 = idle, 1 = tap must be reported, 2 = tap key is down
static uint16_t shift_tap_end_ms = 0;
#endif

#if (NUM_JOYSTICKS >= 1)
static uint8_t need_joystick_update[NUM_JOYSTICKS];
#endif

#if (USE_ACCELGYRO)
static uint8_t need_accelgyro_update = 0;
#endif

#if (USE_MOUSE != 0)
static uint8_t need_mouse_update = 0;
static uint8_t mouse_x_last_clk_state = 0;
static uint8_t mouse_x_last_dir_state = 0;
static int8_t mouse_x_count = 0;
static uint8_t mouse_y_last_clk_state = 0;
static uint8_t mouse_y_last_dir_state = 0;
static int8_t mouse_y_count = 0;
#if !defined(MOUSE_X_DELTA)
#define MOUSE_X_DELTA 1
#endif
#if !defined(MOUSE_Y_DELTA)
#define MOUSE_Y_DELTA 1
#endif
#endif

#if defined(ENABLE_ANALOG_INPUT)
static uint16_t adc_values[NUM_ADC_CHANNELS] = {0};
static const uint8_t adc_mux_table[NUM_ADC_CHANNELS] = {
	#define MAP(port, pin, mux, minval, maxval, joyid, axis) mux,
	ADC_MAPPING_TABLE(MAP)
	#undef MAP
};
#endif

#if (USE_ACCELGYRO)
/* Nudge (VPINBALL, ADXL335 on A2/A3), see nudge_algo.h
 *
 * Configuration command (8 bytes) from the LWCloneU2 Resurrected Tool, stored in EEPROM:
 *   69, 1, deadzone_mg, filter, tilt_10mg, orient, rebound_pct, check     parameters
 *   69, 2, mask0, mask1, mask2, mask3, hold_10ms, check                    gating outputs
 *   69, 3, action, 0, 0, 0, 0, check     action 1 = take current rest position as zero
 *                                        action 2 = factory defaults
 *   check = 0x69 ^ byte1 ^ ... ^ byte6
 */
#define NUDGE_EEPROM_CFG   0xA0    // behind coil protection (0x80) and PWM frequency (0x88)
#define NUDGE_EEPROM_ZERO  0xB0
#define NUDGE_CFG_MAGIC    0x4E
#define NUDGE_ZERO_MAGIC   0x5B

static nudge_cfg_t g_ncfg;
static nudge_state_t g_nst;
static volatile uint32_t adc_sum[NUM_ADC_CHANNELS];
static volatile uint16_t adc_cnt[NUM_ADC_CHANNELS];
static uint8_t nudge_ch[2];
static int16_t nudge_raw[2];
static uint8_t nudge_have_raw = 0;

/* Rev 0.9c: analog plunger (ADC_MAPPING_TABLE entry with joyid ID_AccelGyro, axis 2)
 *   69, 4, action, seconds, 0, 0, 0, check   action 1 = calibrate (seconds 2..30, 0 = 10)
 *                                             action 2 = delete calibration (plunger off)
 *   69, 3, 3, 0, 0, 0, 0, check              diagnostic: X/Y report the centered sensor
 *                                             values (before filter/dead zone/gating) for 3 s
 */
#define PLUNGER_EEPROM     0xC0
#define PLUNGER_MAGIC      0x50
#define NUDGE_DIAG_TICKS   (3000 / NUDGE_TICK_MS)
static plunger_cfg_t g_pcfg;
static plunger_state_t g_pst;
static uint8_t plunger_ch = 0xFF;
static uint16_t nudge_diag_t = 0;
#endif


// Shift switch off
PROGMEM const uint8_t NormalMapping[NUMBER_OF_INPUTS] =
{ 
	#define MAP(port, pin, normal_id, shift_id) normal_id,
	PANEL_MAPPING_TABLE(MAP)
	#undef MAP
};

// Shift switch on
PROGMEM const uint8_t ShiftMapping[NUMBER_OF_INPUTS] =
{
	#define MAP(port, pin, normal_id, shift_id) shift_id,
	PANEL_MAPPING_TABLE(MAP)
	#undef MAP
};


#define IsKeyDown(index) (InputState[index] & 0x80)

static uint8_t GetKeyNormalMap(unsigned char index) { return (index < NUMBER_OF_INPUTS) ? pgm_read_byte(NormalMapping + index) : 0; }
static uint8_t GetKeyShiftMap(unsigned char index) { return (index < NUMBER_OF_INPUTS) ? pgm_read_byte(ShiftMapping + index): 0; }
static uint8_t IsKeyboardCode(uint8_t key) { return (key >= KEY_A) && (key <= MOD_RightGUI); }
static uint8_t IsModifierCode(uint8_t key) { return (key >= MOD_LeftControl) && (key <= MOD_RightGUI); }
static uint8_t IsConsumerCode(uint8_t key) { return (key >= AC_VolumeUp) && (key <= AC_Mute); }
static uint8_t GetKey(uint8_t index) { return (shift_key != 0) ? GetKeyShiftMap(index) : GetKeyNormalMap(index); }


#if (NUM_JOYSTICKS >= 1)

static uint8_t IsJoystickCode(uint8_t key, uint8_t joy)
{
	key -= (joy * NR_OF_EVENTS_PER_JOY);

	return (key >= J1_Left) && (key < (J1_Left + NR_OF_EVENTS_PER_JOY));
}

static uint8_t NeedJoystickUpdate(void)
{
	uint8_t i;

	for (i = 0; i < NUM_JOYSTICKS; i++)
	{
		if (need_joystick_update[i]) {
			return 1;
		}
	}

	return 0;
}

#endif

#if (USE_ACCELGYRO)

static uint8_t IsAccelGyroCode(uint8_t key)
{
	key -= (4 * NR_OF_EVENTS_PER_JOY);

	return (key >= J1_Left) && (key < (J1_Left + NR_OF_EVENTS_PER_JOY));
}

#endif

#if (USE_MOUSE != 0)

static uint8_t IsMouseButtonCode(uint8_t key)
{
	return (key >= MB_Left) && (key <= MB_Middle);
}

static void MouseMoveX(uint8_t direction)
{
	if (direction)
	{
		if (mouse_x_count > -(127 - MOUSE_X_DELTA)) {
		    mouse_x_count -= MOUSE_X_DELTA;
		}
	}
	else
	{
		if (mouse_x_count < (127 - MOUSE_X_DELTA)) {
		    mouse_x_count += MOUSE_X_DELTA;
		}
	}

	need_mouse_update = 1;
}

static void MouseMoveY(uint8_t direction)
{
	if (direction)
	{
		if (mouse_y_count > -(127 - MOUSE_Y_DELTA)) {
		    mouse_y_count -= MOUSE_Y_DELTA;
		}
	}
	else
	{
		if (mouse_y_count < (127 - MOUSE_Y_DELTA)) {
		    mouse_y_count += MOUSE_Y_DELTA;
		}
	}

	need_mouse_update = 1;
}

static void CheckMouseUpdate(void)
{
	#if defined(MOUSE_X_CLK_INDEX) && defined(MOUSE_X_DIR_INDEX)

	uint8_t mouse_clk_state = InputState[MOUSE_X_CLK_INDEX];
	uint8_t mouse_dir_state = InputState[MOUSE_X_DIR_INDEX];

	if (mouse_clk_state != mouse_x_last_clk_state)
	{
		if (mouse_dir_state == mouse_x_last_dir_state) {
			MouseMoveX(mouse_clk_state ^ mouse_dir_state);
		}

		mouse_x_last_clk_state = mouse_clk_state;
	}

	if (mouse_dir_state != mouse_x_last_dir_state)
	{
		if (mouse_clk_state == mouse_x_last_clk_state) {
			MouseMoveX(!(mouse_clk_state ^ mouse_dir_state));
		}

		mouse_x_last_dir_state = mouse_dir_state;
	}

	#endif

	#if defined(MOUSE_Y_CLK_INDEX) && defined(MOUSE_Y_DIR_INDEX)

	mouse_clk_state = InputState[MOUSE_Y_CLK_INDEX];
	mouse_dir_state = InputState[MOUSE_Y_DIR_INDEX];

	if (mouse_clk_state != mouse_y_last_clk_state)
	{
		if (mouse_dir_state == mouse_y_last_dir_state) {
			MouseMoveY(mouse_clk_state ^ mouse_dir_state);
		}

		mouse_y_last_clk_state = mouse_clk_state;
	}

	if (mouse_dir_state != mouse_y_last_dir_state)
	{
		if (mouse_clk_state == mouse_y_last_clk_state) {
			MouseMoveY(!(mouse_clk_state ^ mouse_dir_state));
		}

		mouse_y_last_dir_state = mouse_dir_state;
	}

	#endif
}

static uint8_t NeedMouseUpdate(void) { return need_mouse_update; }

#endif

#if (USE_ACCELGYRO)

static uint8_t nudge_check(const uint8_t *p8bytes)
{
	uint8_t c = 0x69;
	for (uint8_t i = 1; i < 7; i++) c ^= p8bytes[i];
	return c;
}

static void nudge_save_cfg(void)
{
	uint8_t b[12];
	b[0] = NUDGE_CFG_MAGIC;
	b[1] = g_ncfg.deadzone_mg;
	b[2] = g_ncfg.filter;
	b[3] = g_ncfg.tilt_10mg;
	b[4] = g_ncfg.orient;
	b[5] = g_ncfg.rebound_pct;
	b[6] = g_ncfg.gate_hold_10ms;
	b[7] = (uint8_t)(g_ncfg.gate_mask);
	b[8] = (uint8_t)(g_ncfg.gate_mask >> 8);
	b[9] = (uint8_t)(g_ncfg.gate_mask >> 16);
	b[10] = (uint8_t)(g_ncfg.gate_mask >> 24);
	b[11] = 0;
	for (uint8_t i = 0; i < 11; i++) b[11] ^= b[i];
	eeprom_update_block((const void*)b, (void*)NUDGE_EEPROM_CFG, sizeof(b));
}

static void nudge_save_zero(uint8_t valid, int16_t zx, int16_t zy)
{
	uint8_t b[6];
	b[0] = valid ? NUDGE_ZERO_MAGIC : 0xFF;
	b[1] = (uint8_t)zx; b[2] = (uint8_t)((uint16_t)zx >> 8);
	b[3] = (uint8_t)zy; b[4] = (uint8_t)((uint16_t)zy >> 8);
	b[5] = b[0] ^ b[1] ^ b[2] ^ b[3] ^ b[4];
	eeprom_update_block((const void*)b, (void*)NUDGE_EEPROM_ZERO, sizeof(b));
}

static void plunger_save(void)
{
	uint8_t pb[6];
	pb[0] = g_pcfg.valid ? PLUNGER_MAGIC : 0xFF;
	pb[1] = (uint8_t)g_pcfg.rest; pb[2] = (uint8_t)(g_pcfg.rest >> 8);
	pb[3] = (uint8_t)g_pcfg.max;  pb[4] = (uint8_t)(g_pcfg.max >> 8);
	pb[5] = pb[0] ^ pb[1] ^ pb[2] ^ pb[3] ^ pb[4];
	eeprom_update_block((const void*)pb, (void*)PLUNGER_EEPROM, sizeof(pb));
}

static void nudge_load(void)
{
	uint8_t b[12];
	uint8_t c = 0;

	#define MAP(port, pin, mux, minval, maxval, joyid, axis) \
		if ((joyid == ID_AccelGyro) && (axis < 2)) { nudge_ch[axis] = port##pin##_adcindex; } \
		if ((joyid == ID_AccelGyro) && (axis == 2)) { plunger_ch = port##pin##_adcindex; }
	ADC_MAPPING_TABLE(MAP)
	#undef MAP

	plunger_init(&g_pst);
	g_pcfg.valid = 0;
	#if defined(DIDR2) && defined(ADC15D)
	if (plunger_ch != 0xFF) DIDR2 |= (1 << ADC15D);   // A15 analog only (no digital input buffer)
	#endif
	{
		uint8_t pb[6];
		eeprom_read_block((void*)pb, (const void*)PLUNGER_EEPROM, sizeof(pb));
		if (pb[0] == PLUNGER_MAGIC && pb[5] == (uint8_t)(pb[0] ^ pb[1] ^ pb[2] ^ pb[3] ^ pb[4]))
		{
			g_pcfg.rest = (uint16_t)pb[1] | ((uint16_t)pb[2] << 8);
			g_pcfg.max = (uint16_t)pb[3] | ((uint16_t)pb[4] << 8);
			g_pcfg.valid = 1;
			if (!plunger_cfg_ok(&g_pcfg)) g_pcfg.valid = 0;
		}
	}

	eeprom_read_block((void*)b, (const void*)NUDGE_EEPROM_CFG, sizeof(b));
	for (uint8_t i = 0; i < 11; i++) c ^= b[i];

	nudge_cfg_defaults(&g_ncfg);

	if (b[0] == NUDGE_CFG_MAGIC && b[11] == c)
	{
		g_ncfg.deadzone_mg = b[1];
		g_ncfg.filter = b[2];
		g_ncfg.tilt_10mg = b[3];
		g_ncfg.orient = b[4];
		g_ncfg.rebound_pct = b[5];
		g_ncfg.gate_hold_10ms = b[6];
		g_ncfg.gate_mask = (uint32_t)b[7] | ((uint32_t)b[8] << 8) | ((uint32_t)b[9] << 16) | ((uint32_t)b[10] << 24);
		nudge_cfg_sanitize(&g_ncfg);
	}

	uint8_t z[6];
	eeprom_read_block((void*)z, (const void*)NUDGE_EEPROM_ZERO, sizeof(z));
	uint8_t const zvalid = (z[0] == NUDGE_ZERO_MAGIC) && (z[5] == (uint8_t)(z[0] ^ z[1] ^ z[2] ^ z[3] ^ z[4]));
	int16_t const zx = (int16_t)((uint16_t)z[1] | ((uint16_t)z[2] << 8));
	int16_t const zy = (int16_t)((uint16_t)z[3] | ((uint16_t)z[4] << 8));

	nudge_init(&g_nst, zvalid && zx > 0 && zx < NUDGE_RAW_MAX && zy > 0 && zy < NUDGE_RAW_MAX, zx, zy);
}

void panel_nudge_config(uint8_t *p8bytes)
{
	if (p8bytes[7] != nudge_check(p8bytes))
		return;

	switch (p8bytes[1])
	{
	case 1:
		g_ncfg.deadzone_mg = p8bytes[2];
		g_ncfg.filter = p8bytes[3];
		g_ncfg.tilt_10mg = p8bytes[4];
		g_ncfg.orient = p8bytes[5];
		g_ncfg.rebound_pct = p8bytes[6];
		nudge_cfg_sanitize(&g_ncfg);
		nudge_save_cfg();
		break;

	case 2:
		g_ncfg.gate_mask = (uint32_t)p8bytes[2] | ((uint32_t)p8bytes[3] << 8) | ((uint32_t)p8bytes[4] << 16) | ((uint32_t)p8bytes[5] << 24);
		g_ncfg.gate_hold_10ms = p8bytes[6];
		nudge_save_cfg();
		break;

	case 3:
		if (p8bytes[2] == 1 && nudge_have_raw)
		{
			int16_t zx, zy;
			nudge_set_zero(&g_nst, &zx, &zy);
			nudge_save_zero(1, zx, zy);
		}
		else if (p8bytes[2] == 3)
		{
			nudge_diag_t = NUDGE_DIAG_TICKS;
		}
		else if (p8bytes[2] == 2)
		{
			nudge_cfg_defaults(&g_ncfg);
			nudge_save_cfg();
			nudge_save_zero(0, 0, 0);
			nudge_init(&g_nst, 0, 0, 0);
		}
		break;

	case 4:
		if (plunger_ch == 0xFF)
			break;
		if (p8bytes[2] == 1)
		{
			plunger_cal_start(&g_pst, p8bytes[3] ? p8bytes[3] : 10);
		}
		else if (p8bytes[2] == 2)
		{
			g_pcfg.valid = 0;
			plunger_save();
			plunger_init(&g_pst);
		}
		break;

	default:
		break;
	}
}

/* every DELTA_TIME_PANEL_REPORT_MS (= NUDGE_TICK_MS): average of the ADC samples since the last call */
static void nudge_process(void)
{
	uint8_t got = 1;

	for (uint8_t a = 0; a < 2; a++)
	{
		uint8_t const ch = nudge_ch[a];
		uint32_t sum;
		uint16_t cnt;

		ATOMIC_BLOCK(ATOMIC_FORCEON)
		{
			sum = adc_sum[ch];
			cnt = adc_cnt[ch];
			adc_sum[ch] = 0;
			adc_cnt[ch] = 0;
		}

		if (cnt > 0)
			nudge_raw[a] = (int16_t)((sum << 4) / cnt);
		else if (!nudge_have_raw)
			got = 0;
	}

	if (!got)
		return;

	nudge_have_raw = 1;

	uint8_t const gate = (g_ncfg.gate_mask & led_get_on_mask()) != 0;

	if (nudge_tick(&g_nst, &g_ncfg, nudge_raw, gate))
		need_key_update = 1;    // tilt key T pressed or released

	if (nudge_diag_t > 0)
		nudge_diag_t--;

	if (plunger_ch != 0xFF)
	{
		uint32_t sum;
		uint16_t cnt;

		ATOMIC_BLOCK(ATOMIC_FORCEON)
		{
			sum = adc_sum[plunger_ch];
			cnt = adc_cnt[plunger_ch];
			adc_sum[plunger_ch] = 0;
			adc_cnt[plunger_ch] = 0;
		}

		if (cnt > 0 && plunger_tick(&g_pst, &g_pcfg, (uint16_t)((sum << 4) / cnt)))
			plunger_save();
	}
}

#endif

void panel_init(void)
{
	#if (NUM_JOYSTICKS >= 1)
	memset(&need_joystick_update[0], 0x00, sizeof(need_joystick_update));
	#endif

	#define MAP(port, pin, normal_id, shift_id) \
		PORT##port |= (1 << pin); \
		DDR##port &= ~(1 << pin);
	PANEL_MAPPING_TABLE(MAP)
	#undef MAP

	#if defined(ENABLE_ANALOG_INPUT) && defined(ADC_MAPPING_TABLE)
	#define MAP(port, pin, mux, minval, maxval, joyid, axis) \
		PORT##port &= ~(1 << pin); \
		DDR##port &= ~(1 << pin);
	ADC_MAPPING_TABLE(MAP)
	#undef MAP

	ADC_init();
	#endif

	#if (USE_ACCELGYRO)
	nudge_load();
	#endif
};

static void SetNeedUpdate(uint8_t index)
{
	uint8_t key = GetKey(index);

	if (IsConsumerCode(key))
	{
		need_consumer_update = 1;
		return;
	}

	if (IsKeyboardCode(key))
	{
		need_key_update = 1;
		return;
	}

	#if (USE_MOUSE != 0)
	if (IsMouseButtonCode(key))
	{
		need_mouse_update = 1;
		return;
	}
	#endif

	#if (NUM_JOYSTICKS >= 1)
	{
		uint8_t i;

		for (i = 0; i < NUM_JOYSTICKS; i++)
		{
			if (IsJoystickCode(key, i))
			{
				need_joystick_update[i] = 1;
				return;
			}
		}
	}
	#endif

	#if (USE_ACCELGYRO)
	if (IsAccelGyroCode(key))
	{
		need_accelgyro_update = 1;
		return;
	}
	#endif
}

#if defined(SHIFT_SWITCH_INDEX)

static void ShiftKeyCleanUp(void)
{
	if (shift_key_cleanup == 1)
	{
		uint8_t i;
		shift_key_cleanup = 2;

		for (i = 0; i < NUMBER_OF_INPUTS; i++)
		{
			if (i != SHIFT_SWITCH_INDEX)
			{
				if (InputState[i] != 0)
				{
					if (GetKeyNormalMap(i) != GetKeyShiftMap(i))
					{
						SetNeedUpdate(i);
						InputState[i] = 0;
					}
				}
			}
		}
	}

	if (shift_key_cleanup == 2)
	{
		bool no_update = !need_consumer_update && !need_key_update;

		#if (USE_MOUSE != 0)
		no_update = no_update && !NeedMouseUpdate();
		#endif

		#if (NUM_JOYSTICKS >= 1)
		no_update = no_update && !NeedJoystickUpdate();
		#endif

		#if (USE_ACCELGYRO)
		no_update = no_update && !need_accelgyro_update;
		#endif

		if (no_update)
		{
			shift_key_cleanup = 0;
			shift_key = IsKeyDown(SHIFT_SWITCH_INDEX);
		}
	}
}

#endif

static uint8_t NeedUpdate(void)
{
	#if defined(SHIFT_SWITCH_INDEX) && defined(SHIFT_SWITCH_TAP)
	if ((shift_tap == 2) && (((int16_t)clock_ms() - (int16_t)shift_tap_end_ms) >= 0))
	{
		shift_tap = 0;
		need_key_update = 1;
	}
	#endif

	#if defined(SHIFT_SWITCH_INDEX)
	ShiftKeyCleanUp();
	#endif

	#if (USE_MOUSE != 0)
	if (NeedMouseUpdate())
	{
		need_mouse_update = 0;
		return ID_Mouse;
	}
	#endif

	if (need_key_update)
	{
		need_key_update = 0;
		return ID_Keyboard;
	}

	if (need_consumer_update)
	{
		need_consumer_update = 0;
		return ID_Consumer;
	}

	uint8_t analog_update[NUM_JOYSTICKS + 1] = {0};
	static uint8_t analog_counter[NUM_JOYSTICKS + 1];

	#if (NUM_JOYSTICKS >= 1)
	for (uint8_t i = 0; i < NUM_JOYSTICKS; i++)
	{
		if (analog_counter[i] < 0xFF && need_joystick_update[i])
		    analog_counter[i] += 1;
	}
	#endif

	#if (USE_ACCELGYRO)
	if (analog_counter[NUM_JOYSTICKS] < 0xFF && need_accelgyro_update)
		analog_counter[NUM_JOYSTICKS] += 1;
	#endif

	#if defined(ENABLE_ANALOG_INPUT) && defined(ADC_MAPPING_TABLE)

	#define MAP(port, pin, mux, minval, maxval, joyid, axis) \
	if (joyid >= ID_Joystick1 && (joyid - ID_Joystick1) < NUM_JOYSTICKS) { analog_update[joyid - ID_Joystick1] = 1; } else \
	if (joyid == ID_AccelGyro) { analog_update[NUM_JOYSTICKS] = 1; }
	ADC_MAPPING_TABLE(MAP)
	#undef MAP

	for (uint8_t i = 0; i < sizeof(analog_update) / sizeof(analog_update[0]); i++)
	{
		if (analog_counter[i] < 0xFF && analog_update[i] > 0)
		    analog_counter[i] += 1;
	}

	#endif

	uint8_t ac_max = 0;
	int8_t index_max = -1;

	for (int8_t i = 0; i < sizeof(analog_update) / sizeof(analog_update[0]); i++)
	{
		if (ac_max < analog_counter[i])
		{
			ac_max = analog_counter[i];
			index_max = i;
		}
	}

	if (index_max >= 0)
	{
		analog_counter[index_max] = 0;

		#if (NUM_JOYSTICKS >= 1)
		if (index_max < NUM_JOYSTICKS) {
			need_joystick_update[index_max] = 0;
			return index_max + ID_Joystick1;
		}
		#endif

		#if (USE_ACCELGYRO)
		need_accelgyro_update = 0;
		return ID_AccelGyro;
		#endif
	}

	return ID_Unknown;
}

static void SetInputCount(uint8_t index, uint8_t condition)
{
	#if (USE_MOUSE != 0) && defined(MOUSE_X_CLK_INDEX) && defined(MOUSE_X_DIR_INDEX)
	if ((index == MOUSE_X_CLK_INDEX) || (index == MOUSE_X_DIR_INDEX))
	{
		InputState[index] = condition;
		return;
	}
	#endif

	#if (USE_MOUSE != 0) && defined(MOUSE_Y_CLK_INDEX) && defined(MOUSE_Y_DIR_INDEX)
	if ((index == MOUSE_Y_CLK_INDEX) || (index == MOUSE_Y_DIR_INDEX))
	{
		InputState[index] = condition;
		return;
	}
	#endif

	if (index >= NUMBER_OF_INPUTS)
	{
		return;
	}

	#if defined(MULTIFIRE_INDEX)
	if (index == MULTIFIRE_INDEX)
	{
		static uint16_t ncycle = 0;
		static uint8_t ncount = 0;
		static uint8_t ndelay = 0;

		// simple debounce
		if (ndelay == 0 && condition)
		{
			ndelay = (100 / (DELTA_TIME_PANEL_REPORT_MS + 1));
			ncount += MULTIFIRE_COUNT;
		}
		else if (ndelay > 1)
		{
			ndelay--;
		}
		else if (ndelay == 1)
		{
			if (!condition)
				ndelay = 0;
		}

		condition = 0;

		// state machine to generate multiple events
		if (ncount > 0)
		{
			condition = (ncycle < (100 / (DELTA_TIME_PANEL_REPORT_MS + 1))) ? 1 : 0;

			if (ncycle >= (600 / (DELTA_TIME_PANEL_REPORT_MS + 1)))
			{
				ncycle = 0;
				ncount -= 1;
			}
			else
			{
				ncycle += 1;
			}
		}
	}
	#endif

	uint8_t changed = 0;
	uint8_t count = InputState[index];
	uint8_t state = count & 0x80;
	count &= 0x7f;

	if (condition)
	{
		if (count <= DEBOUNCE)
		{
			if ((count == DEBOUNCE) && !state)
			{
				changed = 1;
				state = 0x80;
			}

			count++;
		}
		else
		{
			return;
		}
	}
	else
	{
		if (count > 0)
		{
			if ((count == 1) && state)
			{
				changed = 1;
				state = 0;
			}

			count--;
		}
		else
		{
			return;
		}
	}

	InputState[index] = state | count;

	if (changed)
	{
		#if defined(SHIFT_SWITCH_INDEX)
		if (index == SHIFT_SWITCH_INDEX)
		{
			shift_key_cleanup = 1;

			#if defined(SHIFT_SWITCH_TAP)
			if (state) {
				shift_used = 0;
			} else if (!shift_used) {
				shift_tap = 1;
				need_key_update = 1;
			}
			#endif
		}
		else
		#endif
		{
			#if defined(SHIFT_SWITCH_INDEX) && defined(SHIFT_SWITCH_TAP)
			if (state && IsKeyDown(SHIFT_SWITCH_INDEX)) {
				shift_used = 1;
			}
			#endif

			SetNeedUpdate(index);
		}
	}
}

void panel_ScanInput(void)
{
	if (shift_key_cleanup) {
		return;
	}

	#define MAP(port, pin, normal_id, shift_id) SetInputCount(port##pin##_index, 0 == (PIN##port & (1 << pin)));
	PANEL_MAPPING_TABLE(MAP)
	#undef MAP

	#if (USE_MOUSE != 0)
	CheckMouseUpdate();
	#endif
}

#if (USE_CONSUMER != 0)
static uint8_t ReportConsumer(void)
{
	uint8_t i;
	uint8_t consumer = 0;

	for (i = 0; i < NUMBER_OF_INPUTS; i++)
	{
		if (IsKeyDown(i))
		{
			uint8_t key = GetKey(i);

			if (IsConsumerCode(key)) {
				consumer |= ConsumerBit(key);
			}
		}
	}

	ReportBuffer[0] = ID_Consumer;
	ReportBuffer[1] = consumer;

	return 2;
}
#endif

static uint8_t ReportKeyboard(void)
{
	uint8_t i;
	uint8_t r = 2;

	memset(&ReportBuffer[1], 0x00, sizeof(ReportBuffer) - 1);

	ReportBuffer[0] = ID_Keyboard;

	for (i = 0; i < NUMBER_OF_INPUTS; i++)
	{
		#if defined(SHIFT_SWITCH_INDEX) && defined(SHIFT_SWITCH_TAP)
		if (i == SHIFT_SWITCH_INDEX) {
			continue;   // its own key is only sent as a tap on release (see below)
		}
		#endif

		if (IsKeyDown(i))
		{
			uint8_t key = GetKey(i);

			if (IsKeyboardCode(key))
			{
				if (IsModifierCode(key))
				{
					ReportBuffer[1] |= ModifierBit(key);
				}
				else
				{
					if (r < sizeof(ReportBuffer))
					{
						switch (key)
						{
						case KM_ALT_F4:
							ReportBuffer[1] |= ModifierBit(MOD_LeftAlt);
							ReportBuffer[r] = KEY_F4;
							break;
						case KM_SHIFT_F7:
							ReportBuffer[1] |= ModifierBit(MOD_LeftShift);
							ReportBuffer[r] = KEY_F7;
							break;
						default:
							ReportBuffer[r] = key;
							break;
						}

						r++;
					}
				}
			}
		}
	}

	#if defined(SHIFT_SWITCH_INDEX) && defined(SHIFT_SWITCH_TAP)
	if (shift_tap != 0)
	{
		uint8_t const key = GetKeyNormalMap(SHIFT_SWITCH_INDEX);

		if (IsModifierCode(key)) {
			ReportBuffer[1] |= ModifierBit(key);
		} else if (r < sizeof(ReportBuffer)) {
			ReportBuffer[r] = key;
			r++;
		}

		if (shift_tap == 1) {
			shift_tap = 2;
			shift_tap_end_ms = clock_ms() + SHIFT_TAP_MS;
		}
	}
	#endif

	#if (USE_ACCELGYRO)
	if ((g_nst.tilt_t > 0) && (r < sizeof(ReportBuffer)))
	{
		ReportBuffer[r] = KEY_T;    // tilt from the accelerometer (Visual Pinball: mechanical tilt)
		r++;
	}
	#endif

	return sizeof(ReportBuffer);
}

#if defined(ENABLE_ANALOG_INPUT)

uint16_t ADC_getvalue(uint8_t id)
{
	uint16_t x;

	ATOMIC_BLOCK(ATOMIC_FORCEON)
	{
		x = adc_values[id];
	}

	return x;
}

static int16_t joyval12(uint16_t x, int16_t minval, int16_t maxval)
{
	return (int16_t)(((int32_t)x * (int32_t)(maxval - minval) + (1 << 9)) >> 10) + minval - 2047;
}

static int8_t joyval8(uint16_t x, int16_t minval, int16_t maxval)
{
	return (int8_t)(((int32_t)x * (int32_t)(maxval - minval) + (1 << 9)) >> 10) + minval - 127;
}

#endif

#if (NUM_JOYSTICKS >= 1)

static uint8_t ReportJoystick(uint8_t id)
{
	uint8_t i;
	int16_t joy_x = 0;
	int16_t joy_y = 0;
	uint8_t joy_b = 0;

	ReportBuffer[0] = id;

	#if defined(ENABLE_ANALOG_INPUT) && defined(ADC_MAPPING_TABLE)
	#define MAP(port, pin, mux, minval, maxval, joyid, axis) \
		if ((axis == 0) && (joyid == id)) { joy_x = joyval12(ADC_getvalue(port##pin##_adcindex), (int16_t)(minval * 4094), (int16_t)(maxval * 4094)); } \
		if ((axis == 1) && (joyid == id)) { joy_y = joyval12(ADC_getvalue(port##pin##_adcindex), (int16_t)(minval * 4094), (int16_t)(maxval * 4094)); }
	ADC_MAPPING_TABLE(MAP)
	#undef MAP
	#endif

	id = (id - ID_Joystick1) * NR_OF_EVENTS_PER_JOY;

	for (i = 0; i < NUMBER_OF_INPUTS; i++)
	{
		if (IsKeyDown(i))
		{
			uint8_t key = GetKey(i) - id;
			switch (key)
			{
			case J1_Left:
				joy_x = -2047;
				break;
			case J1_Right:
				joy_x = +2047;
				break;
			case J1_Up:
				joy_y = -2047;
				break;
			case J1_Down:
				joy_y = +2047;
				break;

			case J1_Button1:
			case J1_Button2:
			case J1_Button3:
			case J1_Button4:
			case J1_Button5:
			case J1_Button6:
			case J1_Button7:
			case J1_Button8:
				joy_b |= JoyButtonBit(key);
				break;

			default:
				break;
			}
		}
	}

	ReportBuffer[1] = ((uint16_t)joy_x & 0xFF);
	ReportBuffer[2] = (((uint16_t)joy_y & 0x0F) << 4) | (((uint16_t)joy_x >> 8) & 0x0F);
	ReportBuffer[3] = (((uint16_t)joy_y >> 4) & 0xFF);
	ReportBuffer[4] = joy_b;

	return 5;
}

#endif

#if (USE_ACCELGYRO)

static uint8_t ReportAccelGyro(uint8_t id)
{
	(void)id;

	int16_t x = g_nst.out[0];
	int16_t y = g_nst.out[1];
	uint8_t st = (g_nst.status & 0x0F) | (g_pst.status & 0x70);

	if (nudge_diag_t > 0)
	{
		x = (int16_t)g_nst.raw8[0] * 256;
		y = (int16_t)g_nst.raw8[1] * 256;
		st |= 0x80;
	}

	ReportBuffer[0] = ID_AccelGyro;
	ReportBuffer[1] = (uint8_t)x;
	ReportBuffer[2] = (uint8_t)((uint16_t)x >> 8);
	ReportBuffer[3] = (uint8_t)y;
	ReportBuffer[4] = (uint8_t)((uint16_t)y >> 8);
	ReportBuffer[5] = (uint8_t)g_pst.out;
	ReportBuffer[6] = (uint8_t)((uint16_t)g_pst.out >> 8);
	ReportBuffer[7] = st;

	return 8;
}

#endif


#if (USE_MOUSE != 0)

static uint8_t ReportMouse(void)
{
	uint8_t i;
	uint8_t buttons = 0;

	for (i = 0; i < NUMBER_OF_INPUTS; i++)
	{
		if (IsKeyDown(i))
		{
			uint8_t key = GetKey(i);

			if (IsMouseButtonCode(key)) {
				buttons |= MouseButtonBit(key);
			}
		}
	}

	ReportBuffer[0] = ID_Mouse;
	ReportBuffer[1] = buttons;
	ReportBuffer[2] = mouse_x_count;
	ReportBuffer[3] = mouse_y_count;
	mouse_x_count = 0;
	mouse_y_count = 0;

	return 4;
}

#endif


static uint8_t BuildReport(uint8_t id)
{
	switch (id)
	{
	#if (USE_KEYBOARD != 0)
	case ID_Keyboard:
		return ReportKeyboard();
	#endif

	#if (USE_CONSUMER != 0)
	case ID_Consumer:
		return ReportConsumer();
	#endif

	#if (NUM_JOYSTICKS >= 1)
	case ID_Joystick4:
	case ID_Joystick3:
	case ID_Joystick2:
	case ID_Joystick1:
		return ReportJoystick(id);
	#endif

	#if (USE_ACCELGYRO)
	case ID_AccelGyro:
		return ReportAccelGyro(id);
	#endif

	#if (USE_MOUSE != 0)
	case ID_Mouse:
		return ReportMouse();
	#endif

	default:
		break;
	}

	return 0;
}

uint8_t panel_get_report(uint8_t **ppdata)
{
	if (ppdata == NULL) {
		return 0;
	}

	static uint16_t time_next_ms = 0;
	uint16_t const time_curr_ms = clock_ms();

	if (((int16_t)time_curr_ms - (int16_t)time_next_ms) < 0) {
		return 0;
	}

	time_next_ms = time_curr_ms + DELTA_TIME_PANEL_REPORT_MS;

	#if (USE_ACCELGYRO)
	nudge_process();
	#endif

	panel_ScanInput();

	uint8_t const id = NeedUpdate();

	if (id == ID_Unknown) {
		return 0;
	}

	uint8_t const ndata = BuildReport(id);
	*ppdata = ReportBuffer;

	return ndata;
}


#if defined(ENABLE_ANALOG_INPUT)

// ADC Interrupt Routine

ISR(ADC_vect)
{
	#if defined(ENABLE_PROFILING)
	profile_start();
	#endif

	static int i = 0;

	// get value

	uint16_t const adc = ADC;
	adc_values[i] = adc;

	#if (USE_ACCELGYRO)
	if (adc_cnt[i] < 4000) {
		adc_sum[i] += adc;
		adc_cnt[i]++;
	}
	#endif

	// cycle

	i -= 1;

	if (i < 0) 
		i += NUM_ADC_CHANNELS;

	// set mux channel for the next conversion

	ADC_setmux(adc_mux_table[i]);

	// start new conversion

	ADCSRA |= (1 << ADSC);
}

#endif



#endif
